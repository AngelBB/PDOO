#encoding: utf-8
require_relative "Qytetet.rb"
require_relative "vista_textual_qytetet.rb"
require_relative "jugador.rb"
require_relative "sorpresa"
require_relative "tipo_sorpresa"
require_relative "tablero"
require_relative "casilla"
require_relative "tipo_casilla"


module InterfazTextualQytetet
  include ModeloQytetet
  class ControladorQytetet
    
    def inicializacion_juego
      @vista=VistaTextualQytetet.new
      @juego=ModeloQytetet::Qytetet.instance
      nombre_jugadores=Array.new
      nombre_jugadores=@vista.obtener_nombre_jugadores
      @juego.inicializar_juego(nombre_jugadores)
    end
    
    def desarrollo_juego
      puts "****EMPIEZA EL JUEGO****"
      
      while (!bancarrota)
        @vista.mostrar("===== Nuevo turno =====")
        @jugador=@juego.jugador_actual
        @casilla=@jugador.casilla_actual
        @vista.mostrar("Nuevo turno de jugador :\n " + @jugador.to_s)
        @vista.mostrar("Jugando en casilla: " + @casilla.to_s)
        @vista.esperar       
        
        #2.1 MOVIMIENTO
        #A)Si esta en la carcel
        resultado=@jugador.encarcelado
        if (resultado)
          @vista.mostrar("¡Estas encarcelado!")
          opc=@vista.menu_salir_carcel
          if(opc==0)
            resultado=@juego.intentar_salir_carcel(ModeloQytetet::MetodoSalirCarcel::PAGANDOLIBERTAD)
          elsif(opc == 1)
            resultado=@juego.intentar_salir_carcel(ModeloQytetet::MetodoSalirCarcel::TIRANDODADO)
          end
          
          if(resultado)
            @vista.mostrar("¡Enhorabuena!, has salido de la carcel")
          else
            @vista.mostrar("¡Oh no!, sigues en la carcel")
          end
        end
                
        #B) Si el jugador no esta en la carcel
        if(!@jugador.encarcelado && @jugador.obtener_capital>0)
          #NOTA: El metodo jugar se encargara de cobrar el alquiler
#          puts 'VAMOS A JUGAR'
          @juego.jugar
#          puts "Casilla inicio de la tirada: #{@casilla.to_s}" 
          if(@casilla.tipo == ModeloQytetet::TipoCasilla::SORPRESA)
            @vista.mostrar("Has obtenido la carta sorpresa: #{@juego.carta_actual.to_s}")
            @juego.aplicar_sorpresa
          elsif (@casilla.tipo == ModeloQytetet::TipoCasilla::CALLE)
            @vista.mostrar("Has caido en la calle: \n #{ @casilla.to_s}")
            if(!@casilla.tengo_propietario)
              confirmacion=@vista.elegir_quiero_comprar
              if (confirmacion)
                  @juego.comprar_titulo_propiedad
              end
            end
          elsif(@casilla.tipo == ModeloQytetet::TipoCasilla::JUEZ)
            @vista.mostrar("El juez te ha encarcelado")
          end
            
          #2.2)Gestion inmobiliaria  
          if(!@jugador.encarcelado && @jugador.obtener_capital > 0 && @jugador.tengo_propiedades)
            prop_hipotecada=Array.new
            prop_no_hipotecada=Array.new
          
            prop_hipotecada=@juego.propiedades_hipotecadas_jugador(true);
            prop_no_hipotecada=@juego.propiedades_hipotecadas_jugador(false);
          
            opc=@vista.menu_gestion_inmobiliaria
          
            case opc
             when 0
              #no hacemos nada
             when 1
              @casilla=elegir_propiedad(prop_no_hipotecada)
              @juego.edificar_casa(@casilla)
               if(@juego.edificar_casa(@casilla))
                @vista.mostrar("Casa edificada")
               else
                 @vista.mostrar("Casa NO edificada")
               end
              when 2
                @casilla=elegir_propiedad(prop_no_hipotecada)
                if(@juego.edificarHotel(@casilla))
                  @vista.mostrar("Hotel edificado")
                else
                  @vista.mostrar("Hotel NO edificado")
                end
              when 3
               @casilla=elegir_propiedad(prop_no_hipotecada)
                if(@juego.venderPropiedad(@casilla))
                  @vista.mostrar("Propiedad vendida")
                else
                  @vista.mostrar("Propiedad NO vendida")
                end
              when 4
               @casilla=elegir_propiedad(prop_no_hipotecada)
                if(@juego.hipotecar_propiedad(@casilla))
                  @vista.mostrar("Propiedad hipotecada")
                else
                  @vista.mostrar("Propiedad NO hipotecada")
                end
              when 5
               @casilla=elegir_propiedad(prop_hipotecada)
               if(@juego.cancelarHipoteca(@casilla))
                  @vista.mostrar("hipoteca cancelada")
                else
                  @vista.mostrar("hipoteca NO cancelada")
               end
              else
                @vista.mostrar("Error en metodo gestion inmobiliaria")
             end
          end
        end 
        @juego.siguiente_jugador
      end #while 

      #FIN JUEGO
      #4. DesarrolloJuego: Fin del juego ha ocurrido una bancarrota
      if(bancarrota)
        @vista.mostrar("JUEGO FINALIZADO")
        @vista.mostrar("Ranking:")
        ranking=Hash.new
        ranking.each do |key, value|
          @vista.mostrar("#{key}: #{value} €")
        end
      end
    end#fin metodo desarrollo_juego
     
    def elegir_propiedad (propiedades) # lista de propiedades a elegir
        @vista.mostrar("\tCasilla\tTitulo");
        listaPropiedades= Array.new
        for prop in propiedades  # crea una lista de strings con numeros y nombres de propiedades
                propString= prop.numero_casilla.to_s+' '+prop.titulo.nombre; 
                listaPropiedades<<propString
        end
        seleccion=@vista.menu_elegir_propiedad(listaPropiedades)  # elige de esa lista del menu
        propiedades.at(seleccion)
    end
    
    def cadena_info
      ret=("Mazo:\n #{@juego.mazo.to_s}
        \nTablero:\n #{@juego.tablero.to_s}
        \nJugador actual:\n #{@jugador.to_s}
        \nCasilla actual:\n #{@casilla.to_s}")
     return ret
    end
    
    def bancarrota
      for j in @juego.jugadores
        if j.obtener_capital <= 0
          return true
        end  
      end
      return false
    end
    
  end#FIN CLASE INTERFAZ

  #====== LANZAMIENTO ======
  cq=ControladorQytetet.new
  cq.inicializacion_juego
  cq.desarrollo_juego

end


