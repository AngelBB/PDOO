# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require "singleton"

module ModeloQytetet
  class Dado
    include Singleton
    def initialize

    end
    
    def tirar
     entero=rand(1..6)
#      puts "Dado ha salido : #{entero}"
      entero
     end
    
    #private_class_method :new
    
  end
end