#encoding: utf-8
require_relative "sorpresa"
require_relative "tipo_sorpresa"
require_relative "tablero"
require_relative "casilla"
require_relative "tipo_casilla"
require_relative "Qytetet"

module ModeloQytetet 
  #Crea la clase PruebaQytetet con el atributo de clase mazo teniendo en cuenta que la
  #clase equivalente a ArrayList en Ruby se llama Array
  class PruebaQytetet
    def initialize
      @@mazo=Array.new
    end

    #Define el método de clase inicializar_sorpresas. Como en Java, en el método se
    #crearán e incluirán en el mazo todos los objetos sorpresa. 
    def self.inicializar_sorpresas
      @@mazo=Array.new # Por si acaso ....
      @tablero=Tablero.new #Declaramos el tablero
      @@mazo<< Sorpresa.new("Te ha tocado el bingo ,¡ingresas 2500€!" , 2500,TipoSorpresa::PAGARCOBRAR)
      @@mazo<< Sorpresa.new("Se te ha roto el coche ,¡debes pagar 1000€ para arreglarlo!" , 1000,TipoSorpresa::PAGARCOBRAR)
      @@mazo<< Sorpresa.new("Te hemos pillado con chanclas y calcetines, lo sentimos, ¡debes ir a la carcel!", 9, TipoSorpresa::IRACASILLA)
      @@mazo<< Sorpresa.new("Te echan de menos, ¡debes ir la casilla 13!", 13, TipoSorpresa::IRACASILLA)
      @@mazo<< Sorpresa.new("Final de camino, ¡debes ir la casilla 19!", 19, TipoSorpresa::IRACASILLA)
      @@mazo<< Sorpresa.new("Vaya te ha llegado la factura del IVA,¡tienes que pagar 500€ por cada cada casa o hotel edificado!", 500, TipoSorpresa::PORCASAHOTEL)
      @@mazo<< Sorpresa.new("Han encontrado restos fosiles en tus propiedades,¡recibes 750€ por cada cada casa o hotel edificado!", 750, TipoSorpresa::PORCASAHOTEL)
      @@mazo<< Sorpresa.new("Has perdido la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @@mazo<< Sorpresa.new("Has ganado la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @@mazo<< Sorpresa.new("Un fan anónimo ha pagado tu fianza. Sales de la cárcel", 0, TipoSorpresa::SALIRCARCEL)

    end
    
    #Método 1: Sorpresas que tienen un valor mayor que 0
    private
    def self.mayor_que_cero
      aux=Array.new
      @@mazo.each do |i|
        if i.valor>0
          aux<<i
        end
      end
      aux
    end

     #Método 2: Sorpresas de TipoSorpresa IRACASILLA.
    def self.ir_a_casilla
      aux=Array.new
      @@mazo.each do |i|
        if i.tipo == TipoSorpresa::IRACASILLA
          aux<<i
        end
      end
      aux
    end

    #Método 3: Sorpresas del TipoSorpresa especificado en el argumento del método.
    def self.especifico(v)
      aux=Array.new
      @@mazo.each do |i|
        if i.tipo == v
          aux<<i
        end
      end
      aux
    end
 
#Define un método de clase denominado main donde incluyas las pruebas de los
#métodos que has implementado, de forma equivalente a como hiciste en Java. Para
#mostrar información en la interfaz de texto, usa el método puts.
  public
    def self.main
#      PruebaQytetet.inicializar_sorpresas
#      
#      puts "\nMayor que cero"
#      aux=PruebaQytetet.mayor_que_cero
#      aux.each {|v| puts v.to_s}
#      
#      puts "\nIr a casilla"
#      aux=PruebaQytetet.ir_a_casilla
#      aux.each {|v| puts v.to_s}
#      
#      puts "\nEspecifico"
#      aux=PruebaQytetet.especifico(TipoSorpresa::PORCASAHOTEL)
#      aux.each {|v| puts v.to_s}
#      
#      puts "\nTablero"
#      hola=@tablero.to_s
#      
#      
#      puts hola
#      
       
#    nombres=Array.new
#    nombres<<"Juan"
#    nombres<<"Manolo"
#    
#      principal=Qytetet.instance
#      principal.inicializar_juego(nombres)
#      
#      puts principal.mostrar_tablero
#      puts "\n\n\n"
#      puts principal.mostrar_mazo
#      puts "\n\n\n"
#     
#      puts principal.mostrar_jugadores
     
      
    end
  end
  
  
   #) Invoca al método main desde fuera de la clase PruebaQytetet
  PruebaQytetet.main


end
