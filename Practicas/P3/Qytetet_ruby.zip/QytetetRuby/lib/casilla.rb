#encoding: utf-8

require_relative "tipo_casilla"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Casilla
    
    #Define los consultores básicos para todos los atributos y modificadores básicos de los atributos numHoteles y numCasas. 
    attr_reader :numero_casilla, :coste, :tipo 
    attr_accessor :num_hoteles, :num_casas, :titulo
    
    def initialize(nc,c,nh=0,nca=0,tc,tit)
      @numero_casilla=nc
      @coste=c
      @num_hoteles=nh
      @num_casas=nca
      @tipo=tc
      @titulo=tit
    end
  
    def asignar_propietario(jugador)
      @titulo.propietario=jugador
      return @titulo
    end
    
    def calcular_valor_hipoteca
      hipot_base=@titulo.hipoteca_base
      hipot_base=(hipot_base + (@num_casas * 0.5 *hipot_base) + (@num_hoteles * hipot_base))
      return hipot_base
    end
    
    def cancelar_hipoteca
      devolver=0
      if(esta_hipotecada)
        @titulo.hipotecada=false
        devolver=((calcularValorHipoteca*0.10)+calcularValorHipoteca);
      end
      return devolver
    end
    
    def cobrar_alquiler
      coste_alquiler=@titulo.alquiler_base
      coste_alquiler+=((@num_casas * 0.5)+(@num_hoteles * 2))
      @titulo.cobrar_alquiler(coste_alquiler)
      return coste_alquiler
    end
    
    def edificar_casa
     @num_casas=@num_casas+1
     coste_edificar_casa=@titulo.precio_edificar
     return coste_edificar_casa
    end
    
    def edificar_hotel
      @num_casas=0
      @num_hotel=@num_hotel+1
      coste_edificar_hotel=@titulo.precio_edificar
      return coste_edificar_hotel
    end
    
    def esta_hipotecada
      return (@titulo.hipotecada)
    end
#NO ESTA EN EL DIAGRAMA 
#    def get_coste_hipoteca
#      
#    end
    
    def get_precio_edificar
      return @titulo.precio_edificar
    end
    
    def hipotecar
      @titulo.hipotecada=true
    end
    
    def precio_total_comprar
      
    end
    
    def propietario_encarcelado
      return @titulo.propietario_encarcelado
    end
    
    def se_puede_edificar_casa
      return (@num_casas<4)
    end
    
    def se_puede_edificar_hotel
         return (@num_hoteles<4 && @num_casas==4)
    end
    
    def soy_edificable
      return (@tipo == TipoCasilla::CALLE)
    end
    
    def tengo_propietario
      return (@titulo.tengo_propietario)
    end
    
    def vender_titulo
      @titulo.propietario=nil
      @num_casas=0
      @num_hoteles=0
      precio_compra=@coste+(@num_casas+@num_hoteles)*@titulo.precio_edificar
      precio_venta=(precio_compra+@titulo.factor_revalorizacion * precio_compra)
      return precio_venta
    end
       
    #Define dos constructores: uno para las casillas que no son de tipo calle
    def self.casilla_no_calle(nc,c,tc)
      if(tc != TipoCasilla::CALLE )
        self.new(nc,c,0,0,tc,nil)#CUIDADO CON LOS NULL
      end
    end
   
    # otro para las que son de este tipo y tienen título de propiedad.
    def self.casilla_si_calle(nc,c,tp)
      if(tp != nil)
        self.new(nc,c,0,0,TipoCasilla::CALLE,tp)
      end

    end
    
    def to_s
      if (@titulo.nil?)
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad: -"
      else
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad:\n #{@titulo.to_s}"
      end
    end
        
    #Define el modificador básico setTituloPropiedad() como método privado
    # private :titulo
    
    private
    def asignar_titulo_propiedad

    end
      
  end
end