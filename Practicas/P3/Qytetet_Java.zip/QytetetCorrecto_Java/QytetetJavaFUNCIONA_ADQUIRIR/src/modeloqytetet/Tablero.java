/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import java.util.ArrayList;

/**
 *
 * @author AngelBarrilaoB.
 */

/*Esta clase representa al tablero , que esta formado por un conjunto de casillas*/
public class Tablero {
    
    private ArrayList<Casilla> casillas;
    private Casilla carcel;
    
    
    /*Define un constructor sin argumentos, el consultor del atributo carcel y el método
    toString()*/
    public Tablero() {
        this.inicializar();
    }

    Casilla getCarcel() {
        return carcel;
    }

    @Override
    public String toString() {
        String aux=new String();
        for(Casilla c :casillas){
            aux = aux.concat(c.toString()+"\n");
        }
        return aux;
    }
    /*Define el método privado inicializar(), que será invocado por el constructor.*/
    private void inicializar(){
        casillas=new ArrayList();/* Asigna un nuevo ArrayList al atributo casillas.*/
        carcel=new Casilla(10,0,TipoCasilla.CARCEL);
        casillas.add(new Casilla(0,0,TipoCasilla.SALIDA));
        casillas.add(new Casilla(1,500,new TituloPropiedad("San Anton",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(2,0,TipoCasilla.SORPRESA));
        casillas.add(new Casilla(3,1000,new TituloPropiedad("Recogidas",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(4,1500,new TituloPropiedad("Gran Via",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(5,0,TipoCasilla.JUEZ));
        casillas.add(new Casilla(6,900,new TituloPropiedad("Pedro Antonio",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(7,0,TipoCasilla.SORPRESA));
        casillas.add(new Casilla(8,1250,new TituloPropiedad("Camino de Ronda",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(9,3000,new TituloPropiedad("Reyes Catolicos",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(carcel);
        casillas.add(new Casilla(11,2000,new TituloPropiedad("Avd. Constitucion",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(12,1200,new TituloPropiedad("Avd. de Andalucia",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(13,0,TipoCasilla.PARKING));
        casillas.add(new Casilla(14,3000,new TituloPropiedad("Mesones",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(15,0,TipoCasilla.SORPRESA));
        casillas.add(new Casilla(16,1500,new TituloPropiedad("San Juan de Dios",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(17,1750,new TituloPropiedad("Arabial",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
        casillas.add(new Casilla(18,0,TipoCasilla.IMPUESTO));
        casillas.add(new Casilla(19,2500,new TituloPropiedad("Severo Ochoa",(50 + (int)(Math.random() * 100)),(10 + (int)(Math.random() * 20)),(150 + (int)(Math.random() * 1000)),(250 + (int)(Math.random() * 750)))));
    }
    
    //Metodos del diagrama de clases

    boolean esCasillaCarcel(int numeroCasilla){
        return (casillas.get(numeroCasilla).getTipo() == TipoCasilla.CARCEL);
    }
    Casilla obtenerCasillaNumero(int numeroCasilla){
        //Se presupone que: numeroCasilla>0 AND numeroCasilla<TotalCasillas
        return (casillas.get(numeroCasilla));
    }
    Casilla obtenerNuevaCasilla(Casilla casilla , int desplazamiento){
        /*Casilla la_casilla=casillas.get(casilla.getNumeroCasilla());
        
         if((la_casilla.getNumeroCasilla()+desplazamiento) < casillas.size()){
                return casillas.get(desplazamiento);
         }else{
            int pos=la_casilla.getNumeroCasilla()+1, cont=0;
            while(cont < desplazamiento){
                if(pos< casillas.size()){
                    pos++;
                }else{
                    pos=0;
                }
                cont++;            
            }
            return (casillas.get(pos));
        }*/
        
        int numeroCasilla=casilla.getNumeroCasilla()+desplazamiento;
        if(casillas.size() <= numeroCasilla){
            return casillas.get(numeroCasilla%20);
        }else{
            return casillas.get(numeroCasilla);
        }
    }
}

