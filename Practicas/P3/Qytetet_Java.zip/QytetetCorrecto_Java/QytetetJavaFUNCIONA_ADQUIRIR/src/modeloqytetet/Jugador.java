package modeloqytetet;

import java.util.ArrayList;

/**
 *
 * @author abarrilao
 */
public class Jugador {
    
    //Atributos declarados en el diagramas de clases
    private boolean encarcelado=false;
    private String nombre;
    private int saldo=7500;
    Casilla casillaActual;
    ArrayList<TituloPropiedad> propiedades=new ArrayList();
    Sorpresa cartaLibertad;
    
    
    public Jugador(String nombre){
        this.nombre=nombre;
    }
    
    //Metodos del diagrama de clases
    public Casilla getCasillaActual(){
        return casillaActual;
    }
    public boolean getEncarcelado(){
        return encarcelado;
    }
    public boolean tengoPropiedades(){
        return (propiedades.size()>0);
    }
    boolean actualizarPosicion(Casilla casilla){
    
        if(casilla.getNumeroCasilla()<casillaActual.getNumeroCasilla()){
            this.modificarSaldo(Qytetet.SALDO_SALIDA);//DUDA
        }
        boolean tienePropietario=false;
        this.setCasillaActual(casilla);
        
        if(casilla.soyEdificable()){
           tienePropietario= casilla.tengoPropietario();
            if(tienePropietario){
                if(!casilla.propietarioEncarcelado()){
                    int costeAlquiler=casilla.cobrarAlquiler();
                    this.modificarSaldo((-costeAlquiler));
                }
            }
        }else{
            if(casilla.getTipo()==TipoCasilla.IMPUESTO){
                int coste=casilla.getCoste();
                this.modificarSaldo((-coste));
            }
        
        }
    
        return tienePropietario;
    }
    
    boolean comprarTitulo(){
        boolean puedoComprar=false;
        if(casillaActual.soyEdificable() && !(casillaActual.tengoPropietario()) && (casillaActual.getCoste()<=saldo)){
            int costeCompra=casillaActual.getCoste();
            TituloPropiedad titulo=casillaActual.asignarPropietario(this);
            titulo.setCasilla(casillaActual);
            propiedades.add(titulo);
            this.modificarSaldo((-costeCompra));
            puedoComprar=true;
        }
        return puedoComprar;
    }
    
    
    Sorpresa devolverCartaLibertad(){
        if(cartaLibertad!=null){
            Sorpresa cl=new Sorpresa (cartaLibertad.getTexto(), cartaLibertad.getValor(),cartaLibertad.getTipo());
            cartaLibertad=null;
            return cl;   
        }else{
           return cartaLibertad; 
        }
    }
    
    void irACarcel(Casilla casilla){
        this.setCasillaActual(casilla);
        this.setEncarcelado(true);
    }
    void modificarSaldo(int cantidad){
        saldo+=cantidad;
    }
    public int obtenerCapital(){
        int valor=0;
            for(TituloPropiedad t: propiedades){
                valor+=t.getCasilla().getNumCasas()*t.getCasilla().getCoste();
                valor+=t.getCasilla().getNumHoteles()*t.getCasilla().getCoste();
                if(t.getCasilla().estaHipotecada()){
                    valor-=t.getHipotecaBase();
                }
            }
            return (valor+saldo);   
    }
    public  ArrayList<TituloPropiedad> obtenerPropiedadesHipotecadas(boolean hipotecada){
          ArrayList<TituloPropiedad>tp=new ArrayList();
          for(TituloPropiedad t:propiedades){
              if(hipotecada && t.getHipotecada()){
                    tp.add(t);
              }else if(!hipotecada && !t.getHipotecada()){
                    tp.add(t);
              }
          }
          return tp;
      }
    void pagarCobrarPorCasaYHotel(int cantidad){
        int numeroTotal=this.cuantasCasaHotelesTengo();
        this.modificarSaldo(numeroTotal*cantidad);
    }
    boolean pagarLibertad (int cantidad){
        boolean tengoSaldo=this.tengoSaldo(cantidad);
        if(tengoSaldo){
            this.modificarSaldo(cantidad);
        }
        return tengoSaldo; //DUDA
    }
    boolean puedoEdificarCasa(Casilla casilla){
        boolean tengoSaldo=false;
        if (this.esDeMiPropiedad(casilla)){
            int costeEdificarCasa=casilla.getPrecioEdificar();
            tengoSaldo=this.tengoSaldo(costeEdificarCasa);
        }
        return tengoSaldo;   
    }
    boolean puedoEdificarHotel(Casilla casilla){
    //DUDA REVISAR Y PREGUNTAR
    boolean tengoSaldo=false;
        if (this.esDeMiPropiedad(casilla)){
            int costeEdificarHotel=casilla.getPrecioEdificar();
            tengoSaldo=this.tengoSaldo(costeEdificarHotel);
        }
        return tengoSaldo;   
    
    
    }
    boolean puedoHipotecar(Casilla casilla){
        return this.esDeMiPropiedad(casilla);
    }
    
      /*No esta en el diagrama
      boolean puedoPagarHipoteca(Casilla casilla){}*/
    
    boolean puedoVenderPropiedad(Casilla casilla){
        return (esDeMiPropiedad(casilla) && !casilla.estaHipotecada());
    }
    
    void setCartaLibertad(Sorpresa carta){
        this.cartaLibertad=carta;
    }
    void setCasillaActual(Casilla casilla){
        this.casillaActual=casilla;
    }
    void setEncarcelado(boolean encarcelado){
        this.encarcelado=encarcelado;
    }
    boolean tengoCartaLibertad(){
        return (cartaLibertad != null);
    }
    void venderPropiedad(Casilla casilla){
        int precioVenta=casilla.venderTitulo();
        this.modificarSaldo(precioVenta);
        this.eliminarDeMisPropiedades(casilla);  
    }
    private int cuantasCasaHotelesTengo(){
        int total=0;
        for (TituloPropiedad t:propiedades){
            total+=t.getCasilla().getNumCasas();
            total+=t.getCasilla().getNumHoteles();
        }
        return total;    
    }
    private void eliminarDeMisPropiedades(Casilla casilla){
        propiedades.remove(casilla.getTitulo());
    }
    private boolean esDeMiPropiedad(Casilla casilla){
        return (propiedades.indexOf(casilla.getTitulo()) != -1);
    } 
    boolean tengoSaldo(int cantidad){
        return (saldo>=cantidad);
    }
    @Override
    public String toString() {
        String cadena_propiedades="";
        for (TituloPropiedad tp: propiedades){
            cadena_propiedades+=tp.toString();       
        }
        
         /*Con casilla actual:
        return  "nombre: "+nombre
                +"\nencarcelado: "+encarcelado
                +"\nsaldo: "+saldo
                +"\ncarta_libertad: "+cartaLibertad
                +"\ncasilla actual: "+casillaActual.toString()
                +"\npropiedades: "+cadena_propiedades;*/
        
        return  "nombre: "+nombre
                +"\nencarcelado: "+encarcelado
                +"\nsaldo: "+saldo
                +"\ncarta_libertad: "+cartaLibertad
                +"\npropiedades: "+cadena_propiedades;
    }

    public String getNombre() {
        return nombre;
    }
    
}
