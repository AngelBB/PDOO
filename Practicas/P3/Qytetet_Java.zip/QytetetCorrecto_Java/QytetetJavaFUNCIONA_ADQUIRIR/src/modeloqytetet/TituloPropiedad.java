/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author AngelBarrilaoB.
 */

/*Representa la informacion economica sobre una casilla (Siempre que sea del tipo calle) */
public class TituloPropiedad {
    
    private String nombre;
    private boolean hipotecada;
    private int alquilerBase;
    private float factorRevalorizacion;
    private int hipotecaBase;
    private int precioEdificar;
    
    //Atributos del diagrama de clase
    Jugador propietario;
    Casilla casilla;
            

    /*Define el constructor teniendo en cuenta que no todos los valores para los atributos tienen
    por qué pasarse como argumento, ya que en ocasiones es preferible usar valores por
    defecto*/
    //ATENCION: Habra algunos elementos (todavia no especificados) que interesara darles un valor por defecto
    public TituloPropiedad(String nombre, int alquilerBase, float factorRevalorizacion, int hipotecaBase, int precioEdificar) {
        this.nombre = nombre;
        this.hipotecada = false;
        this.alquilerBase = alquilerBase;
        this.factorRevalorizacion = factorRevalorizacion;
        this.hipotecaBase = hipotecaBase;
        this.precioEdificar = precioEdificar;
    }
/*Define los consultores para todos los atributos, el modificador básico del atributo
hipotecada y el método toString().*/
     public String getNombre() {
        return nombre;
    }

     boolean getHipotecada() {
        return hipotecada;
    }

     void setHipotecada(boolean hipotecada) {
        this.hipotecada = hipotecada;
    }

     int getAlquilerBase() {
        return alquilerBase;
    }

     float getFactorRevalorizacion() {
        return factorRevalorizacion;
    }

     int getHipotecaBase() {
        return hipotecaBase;
    }

     int getPrecioEdificar() {
        return precioEdificar;
    }
     
    Casilla getCasilla(){
        return casilla;
    }

     //Metodos del diagrama de clases
    void cobrarAlquiler(int coste){
        propietario.modificarSaldo((-coste));
    }
    boolean propietarioEncarcelado(){
        return propietario.getEncarcelado();
    }
    void setCasilla(Casilla casilla){
        this.casilla=casilla;
    }
  
    void setPropietario(Jugador propietario){
        this.propietario=propietario;
    }
    boolean tengoPropietario(){
        return (propietario!=null);
    }
         
    @Override
    public String toString() {
        return "nombre: "+ nombre + ", hipotecada: " + hipotecada + ", alquilerBase: " + alquilerBase + ", factorRevalorizacion: " + factorRevalorizacion + ", hipotecaBase: " + hipotecaBase + ", precioEdificar: " + precioEdificar+"\n";
    }
}