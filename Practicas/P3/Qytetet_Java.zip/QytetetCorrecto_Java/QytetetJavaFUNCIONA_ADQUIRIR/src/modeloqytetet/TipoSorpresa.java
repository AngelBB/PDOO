/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author jairoabrilmoya
 * Define el tipo enumerado TipoSorpresa que especifica los tipos de sorpresas existentes.
Para ello, pulsa botón derecho del ratón sobre el paquete y selecciona Nuevo / Java Enum y
define los siguientes valores {PAGARCOBRAR, IRACASILLA, PORCASAHOTEL,
PORJUGADOR, SALIRCARCEL} (investiga cómo definir un enumerado y sus valores en
Java).
 */
public enum TipoSorpresa {
    PAGARCOBRAR , IRACASILLA , PORCASAHOTEL , PORJUGADOR , SALIRCARCEL
}
