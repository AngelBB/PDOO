/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author abarrilao
 */


/* Para generar el singleton nos metemos en la creacion de clase y eleguimos el fichero clase singleton */
public class Dado {
    
    private Dado() {
    }
    
    int tirar(){
        int valorEntero = (int)Math.floor(Math.random()*(6-1+1)+1);  // Valor entre M y N, ambos incluidos.
        return valorEntero;
    }
    public static Dado getInstance() {
        return DadoHolder.INSTANCE;
    }
    
    private static class DadoHolder {

        private static final Dado INSTANCE = new Dado();
    }
}
