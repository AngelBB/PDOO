/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author AngelBarrilaoB.
 * 
 * 
 */
public class Casilla {
    /*Esta clase representa a la casilla que conforma el tablero*/
    
    private int numeroCasilla;
    private int coste;
    private int numHoteles;
    private int numCasas;
    private TipoCasilla tipo;
    private TituloPropiedad titulo;/*Si es una calle pertenecera a un jugador, (tiene titulo).
    De lo contrario no tendra un titular , por ejemplo la casilla carcel, sorpresa, etc*/
    
    /*Define un constructores para las casillas que no son de tipo calle*/
    /*Al estar recien creada la calle no hay ningun hotel ni casa.
    NO los recibimos por parametros , pero SI los inicializamos a cero
    En este constructor al no contemplar la calle, no hay que aniadir tampoco el titular
    */
    public Casilla(int numeroCasilla, int coste, TipoCasilla tipo) {
        if(tipo != TipoCasilla.CALLE){
            this.numeroCasilla = numeroCasilla;
            this.coste = coste;
            this.numHoteles = 0;
            this.numCasas = 0;
            this.tipo = tipo;
            this.titulo = null;//CUIDADO CON ESTO
        }
    }
    /*Define un constructor para las casillas que son de este tipo y tienen título de propiedad.*/
    /*Aqui si metemos el titulo siempre y cuando no este a null y el tipo sea CALLE*/
    public Casilla(int numeroCasilla, int coste, TituloPropiedad titulo) {
        if(titulo != null){
            this.numeroCasilla = numeroCasilla;
            this.coste = coste;
            this.numHoteles = 0;
            this.numCasas = 0;
            this.tipo = TipoCasilla.CALLE;
            this.titulo = titulo;
        }
    }
    /*Define los consultores básicos para todos los atributos y modificadores básicos de los
    atributos numHoteles y numCasas.*/
    void setNumHoteles(int nuevoNumero) {
        this.numHoteles = nuevoNumero;
    }

    void setNumCasas(int nuevoNumero) {
        this.numCasas = nuevoNumero;
    }
       
    public int getNumeroCasilla() {
        return numeroCasilla;
    }

    int getCoste() {
        return coste;
    }

     int getNumHoteles() {
        return numHoteles;
    }

    int getNumCasas() {
        return numCasas;
    }

    public TipoCasilla getTipo() {
        return tipo;
    }

    public TituloPropiedad getTitulo() {
        return titulo;
    }
    /*◦ Define el modificador básico setTituloPropiedad() como método privado.*/
    private void setTitulo(TituloPropiedad titulo){
        this.titulo=titulo;
    }
    /*Define el método toString(). Asegúrate de que si las casillas tienen título de propiedad,
    éste se incluya adecuadamente*/
    @Override
    public String toString() {
        if(titulo != null)
            return "Numero casilla:" + numeroCasilla + ", coste: " + coste + ", numHoteles: " + numHoteles + ", numCasas: " + numCasas + ", tipo: " + tipo + ", titulo: " + titulo.toString();
        else
            return "Numero casilla:" + numeroCasilla + ", coste: " + coste + ", numHoteles: " + numHoteles + ", numCasas: " + numCasas + ", tipo: " + tipo + ", titulo: -";
    }
    
    
    //Metodos del diagrama de clases
    TituloPropiedad asignarPropietario(Jugador jugador){
        titulo.setPropietario(jugador);
        return titulo;
    }
    int calcularValorHipoteca(){
        int hipotecaBase=titulo.getHipotecaBase();
        hipotecaBase=(int) (hipotecaBase + ((numCasas * 0.5 * hipotecaBase) + (numHoteles * hipotecaBase)));
        return hipotecaBase;
    }
    int cancelarHipoteca(){
        int devolver=0;
        if(this.estaHipotecada()){
            titulo.setHipotecada(false);
            devolver=((int)((calcularValorHipoteca()*0.10)+calcularValorHipoteca()));
        }
        return devolver;
    }
    int cobrarAlquiler(){
        int costeAlquilerBase=titulo.getAlquilerBase();
        costeAlquilerBase+= ((numCasas* 0.5) + (numHoteles *2));
        titulo.cobrarAlquiler(costeAlquilerBase);
        return costeAlquilerBase; 
    }
    int edificarCasa(){
        this.setNumCasas(numCasas+1);
        int costeEdificarCasa=titulo.getPrecioEdificar();//DUDA: en el DC edificarCasa, llamada 3.2 costeEdificar=getPrecioCasa()
        return costeEdificarCasa;   
    }
    int edificarHotel(){
        this.setNumCasas(0);
        int costeEdificarHotel=titulo.getPrecioEdificar();//DUDA: en el DC edificarCasa, llamada 3.2 costeEdificar=getPrecioCasa()
        return costeEdificarHotel; 
    
    }
    boolean estaHipotecada(){
        return (titulo.getHipotecada());
    }
    /*No esta en el diagrama
    int getCosteHipoteca(){}*/
    int getPrecioEdificar(){
        return titulo.getPrecioEdificar();
    }
    int hipotecar(){
        titulo.setHipotecada(true);
        int cantidadRecibida=this.calcularValorHipoteca();
        return cantidadRecibida;
    }
    /* No esta en el diagrama
    int precioTotalComprar(){}*/
    boolean propietarioEncarcelado(){
        return titulo.propietarioEncarcelado();
    
    }
    boolean sePuedeEdificarCasa(){
        return (numCasas<4);
    }

    boolean sePuedeEdificarHotel(){
        return (numHoteles<4 && numCasas==4);
    
    }
    boolean soyEdificable(){
        return (tipo == TipoCasilla.CALLE);
    }
    public boolean tengoPropietario(){
        return (titulo.tengoPropietario());
    }

    int venderTitulo(){
        titulo.setPropietario(null);
        this.setNumCasas(0);
        this.setNumHoteles(0);
        int precioCompra=coste+(numCasas+numHoteles)* titulo.getPrecioEdificar();
        int precioVenta=(int) (precioCompra+titulo.getFactorRevalorizacion()* precioCompra);
        return precioVenta;
    }
    private void asignarTituloPropiedad(){}
  
}
