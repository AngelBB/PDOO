/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfazTextualQytetet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import modeloqytetet.*;

/**
 *
 * @author AngelBarrilaoB.
 */
public class ControladorQytetet {
    private VistaTextualQytetet vista=new VistaTextualQytetet();
    private Qytetet juego;
    private Jugador jugador;
    private Casilla casilla;
    
    
    
    public void inizializacionJuego(){
        juego=Qytetet.getInstance();
        ArrayList<String> nombresJugadores;
        nombresJugadores=vista.obtenerNombreJugadores();
        juego.inicializarJuego(nombresJugadores);
    }
        
    public void desarrolloJuego(){
        
        System.out.println("****EMPIEZA EL JUEGO****");
        while(!bancarrota()){
            vista.mostrar("===== Nuevo turno =====");
            jugador=juego.getJugadorActual();
            casilla=jugador.getCasillaActual();
            vista.mostrar("Nuevo turno de jugador :\n " + jugador.toString());
            vista.mostrar("Jugando en casilla: "+casilla.toString());
            vista.esperar();
           
            //2.1 MOVIMIENTO
            //A)Si esta en la carcel
            boolean resultado=jugador.getEncarcelado();
            if(resultado){
                vista.mostrar("¡Estas encarcelado!");
                int opc=vista.menuSalirCarcel();
                if(opc==0){
                    resultado=juego.intentarSalirCarcel(MetodoSalirCarcel.PAGANDOLIBERTAD);
                }else{
                    resultado=juego.intentarSalirCarcel(MetodoSalirCarcel.TIRANDODADO);
                }
                if(resultado){
                    vista.mostrar("¡Enhorabuena!, has salido de la carcel");
                }else{
                    vista.mostrar("¡Oh no!, sigues en la carcel");
                }
            }       

            //B) si el jugador no esta en la carcel
            if(!jugador.getEncarcelado() && jugador.obtenerCapital()>0){
                /*NOTA: El metodo jugar se encargara de cobrar el alquiler */  
                juego.jugar();
                casilla=jugador.getCasillaActual();
                if(casilla.getTipo()==TipoCasilla.SORPRESA){
                    vista.mostrar("Has obtenido la carta sorpresa: "+juego.getCartaActual().toString());
                    juego.aplicarSopresa();
                }else if(casilla.getTipo()==TipoCasilla.CALLE){
                    vista.mostrar("Has caido en la calle: \n" + casilla.toString());
                    if(!casilla.tengoPropietario()){
                        boolean confirmacion=vista.elegirQuieroComprar();
                        if(confirmacion){
                            juego.comprarTituloPropiedad();
                        }
                    }
                }else if(casilla.getTipo()==TipoCasilla.JUEZ){
                    vista.mostrar("El juez te ha encarcelado");
                }
            
                //2.2) Gestión inmobiliaria
                if(!jugador.getEncarcelado() && jugador.obtenerCapital()>0 && jugador.tengoPropiedades()){
                    vista.mostrar("GESTION INMOBILIARIA");
                    ArrayList<Casilla> prop_hipotecada=juego.propiedadesHipotecadasJugador(true);
                    ArrayList<Casilla> prop_no_hipotecada=juego.propiedadesHipotecadasJugador(false);

                    int opc=vista.menuGestionInmobiliaria();
                    switch (opc){
                        case 0: //--No hacemos nada
                            break;
                        case 1:
                            casilla=elegirPropiedad(prop_no_hipotecada);
                            juego.edificarCasa(casilla);
                            if(juego.edificarCasa(casilla))
                                vista.mostrar("Casa edificada");
                            else
                                vista.mostrar("Casa NO edificada");
                            break;
                        case 2: 
                            casilla=elegirPropiedad(prop_no_hipotecada);
                            if(juego.edificarHotel(casilla))
                                vista.mostrar("Hotel edificado");
                            else
                                vista.mostrar("Hotel NO edificado");
                            break;
                        case 3: 
                            casilla=elegirPropiedad(prop_no_hipotecada);
                            if(juego.venderPropiedad(casilla))
                                vista.mostrar("Propiedad vendida");
                            else
                                vista.mostrar("Propiedad NO vendida");
                            break;
                        case 4: 
                            casilla=elegirPropiedad(prop_no_hipotecada);
                            if(juego.hipotecarPropiedad(casilla))
                                vista.mostrar("Propiedad hipotecada");
                             else
                                vista.mostrar("Propiedad NO hipotecada");
                            break;
                        case 5:
                            casilla=elegirPropiedad(prop_hipotecada);
                            if(juego.cancelarHipoteca(casilla))
                                vista.mostrar("hipoteca cancelada");
                            else
                                vista.mostrar("hipoteca NO cancelada");
                            break;
                        default: vista.mostrar("Error en metodo gestion inmobiliaria");
                            break;
                    }
                }
            }
            //SOLO LOS INVOCAMOS UNA VEZ EN EL METODO!!!!
            jugador=juego.siguienteJugador();
        }//while
        
        //FIN JUEGO
       //4. DesarrolloJuego: Fin del juego ha ocurrido una bancarrota
        if(this.bancarrota()){
            vista.mostrar("JUEGO FINALIZADO");
            HashMap<String,Integer> ranking= juego.obtenerRanking();
            vista.mostrar("Ranking: ");
            for(Map.Entry<String,Integer> entrada : ranking.entrySet()) {
                String nombre = entrada.getKey();
                int capital = entrada.getValue();
                vista.mostrar(nombre+": "+capital+" €");
            }
        }
    }//Fin metodo desarrollo_juego
    
    public Casilla elegirPropiedad(ArrayList<Casilla> propiedades){ 
        //este metodo toma una lista de propiedades y genera una lista de strings, con el numero y nombre de las propiedades
        //luego llama a la vista para que el usuario pueda elegir.
        vista.mostrar("\tCasilla\tTitulo");
        int seleccion;
        ArrayList<String> listaPropiedades= new ArrayList();
        for (Casilla cas: propiedades){
            listaPropiedades.add("\t"+cas.getNumeroCasilla()+"\t"+cas.getTitulo().getNombre()); 
        }
        seleccion=vista.menuElegirPropiedad(listaPropiedades);  
        return propiedades.get(seleccion);
    }
    
    public String cadenaInfo(){
        String ret;
        ret=("Mazo:\n "+juego.getMazo().toString()+
        "\nTablero:\n "+juego.getTablero().toString()+
        "\nJugador actual:\n "+jugador.toString()+     
        "\nCasilla actual:\n "+casilla.toString());
        return ret;
    }
    
    public boolean bancarrota(){
       for (Jugador j: juego.getJugadores()){
           if(j.obtenerCapital()<=0){
               return true;
           }
       }
       return false;
    }
    
    public static void main(String[] args) {
        ControladorQytetet cq=new ControladorQytetet();
        cq.inizializacionJuego();
        cq.desarrolloJuego();
    }
}