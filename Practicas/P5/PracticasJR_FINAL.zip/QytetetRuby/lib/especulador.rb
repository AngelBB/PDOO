require_relative "sorpresa"
require_relative "casilla"
require_relative "jugador"
require_relative "titulo_propiedad"
require_relative "Qytetet.rb"
require_relative "jugador.rb"


module ModeloQytetet
  class Especulador < Jugador
    attr_accessor :fianza
    @@Factor_Especulador = 2
    
    def initialize(jug,f)
        copiar_jugador(jug)
        @fianza=f
    end
 
    def pagar_impuestos(cantidad)
     super((cantidad/2))
    end
    
    #DUDA
    def ir_a_carcel(casilla)
      super(casilla)
      if(!pagar_fianza(@fianza))
        @encarcelado=false
      end
    end
    
    def convertirme(fianza)
      @fianza=fianza
      return self
    end
    
    def pagar_fianza(cantidad)
      ts=tengo_saldo(cantidad)
      if(ts)
        modificar_saldo(cantidad)
      end
      return ts
    end
    
    def to_s
      return (super + "fianza: #{@fianza}\n")
    end
    
    def copiar_jugador(jugador)
      @encarcelado=jugador.encarcelado
      @nombre=jugador.nombre
      @saldo=jugador.saldo
      @carta_libertad=jugador.carta_libertad
      @propiedades=jugador.propiedades
      @casilla_actual=jugador.casilla_actual
    end
    
  end
end
