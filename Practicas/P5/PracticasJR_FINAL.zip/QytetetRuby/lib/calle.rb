# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative "tipo_casilla"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Calle < Casilla
    
    attr_accessor :num_hoteles, :num_casas, :titulo
    def initialize(nc,c,tit)
      super(nc,c,TipoCasilla::CALLE)
      @num_hoteles=0
      @num_casas=0
      @titulo=tit
    end
    
    def asignar_propietario(jugador)
      @titulo.propietario=jugador
      return @titulo
    end
    
    def calcular_valor_hipoteca
      hipot_base=@titulo.hipoteca_base
      hipot_base=(hipot_base + (@num_casas * 0.5 *hipot_base) + (@num_hoteles * hipot_base))
      return hipot_base
    end
    
    def cancelar_hipoteca
      devolver=0
      if(esta_hipotecada)
        @titulo.hipotecada=false
        devolver=((calcularValorHipoteca*0.10)+calcularValorHipoteca);
      end
      return devolver
    end
    
    def cobrar_alquiler
      coste_alquiler=@titulo.alquiler_base
      coste_alquiler+=((@num_casas * 0.5)+(@num_hoteles * 2))
      @titulo.cobrar_alquiler(coste_alquiler)
      return coste_alquiler
    end
    
    def edificar_casa
     @num_casas=@num_casas+1
     coste_edificar_casa=@titulo.precio_edificar
     return coste_edificar_casa
    end
    
    def edificar_hotel
      @num_casas=0
      @num_hotel=@num_hotel+1
      coste_edificar_hotel=@titulo.precio_edificar
      return coste_edificar_hotel
    end
    
    def esta_hipotecada
      return (@titulo.hipotecada)
    end
    
    def get_precio_edificar
      return @titulo.precio_edificar
    end
    
    def hipotecar
      @titulo.hipotecada=true
    end
    
    def precio_total_comprar
      
    end
    
    def propietario_encarcelado
      return @titulo.propietario_encarcelado
    end
    
    def se_puede_edificar_casa
      return (@num_casas<4)
    end
    
    def se_puede_edificar_hotel
         return (@num_hoteles<4 && @num_casas==4)
    end
    
    def tengo_propietario
      return (@titulo.tengo_propietario)
    end
    
    def vender_titulo
      @titulo.propietario=nil
      @num_casas=0
      @num_hoteles=0
      precio_compra=@coste+(@num_casas+@num_hoteles)*@titulo.precio_edificar
      precio_venta=(precio_compra+@titulo.factor_revalorizacion * precio_compra)
      return precio_venta
    end
    
    #Practica 4
    def se_puede_edificar_casa_espe(factorEspeculador)
      num_casas_factor=@num_casas*factorEspeculador
      return (@num_casas < num_casas_factor);
    end
    
    def se_puede_edificar_hotel_espe(factorEspeculador)
      num_hoteles_factor=@num_hoteles*factorEspeculador;
      num_casas_factor=@num_casas*factorEspeculador
      return (@num_hoteles < num_hoteles_factor && @num_casas==num_casas_factor);
    end
    
    def to_s
     return (super + " ,num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, titulo propiedad:\n #{@titulo.to_s}")
    end
  end
end
