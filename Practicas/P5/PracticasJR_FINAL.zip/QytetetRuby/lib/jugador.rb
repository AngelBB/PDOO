#encoding: utf-8
require_relative "sorpresa"
require_relative "casilla"
require_relative "titulo_propiedad"
require_relative "Qytetet.rb"
require_relative "especulador.rb"


module ModeloQytetet
  class Jugador
#    attr_writer :carta_libertad 
    attr_accessor :encarcelado, :casilla_actual, :carta_libertad
    attr_reader :nombre, :saldo , :propiedades

    @@Factor_Especulador = 1
    def initialize(n)
      @encarcelado=false
      @nombre=n
      @saldo=7500
      @carta_libertad
      @propiedades=Array.new
      @casilla_actual
    end
    
    def tengo_propiedades
      return (@propiedades.size>0);
    end
    
    def actualizar_posicion(casilla)
      if(casilla.numero_casilla<@casilla_actual.numero_casilla)
         modificar_saldo(1000)#DUDA
        #modificar_saldo(Qytetet.SALDO_SALIDA)
      end
      
      tiene_propietario=false
      @casilla_actual=casilla#MODIFICADO
      
      if(casilla.soy_edificable)
        tiene_propietario=casilla.tengo_propietario
        if(tiene_propietario)
          if(!casilla.propietario_encarcelado)
            coste_alquiler=casilla.cobrar_alquiler
            modificar_saldo((-coste_alquiler))
          end
        end
      elsif(casilla.tipo == TipoCasilla::IMPUESTO)
        coste=casilla.coste
        pagar_impuestos((-coste))
      end
      
      return tiene_propietario
    end
    
    def comprar_titulo
      puedo_comprar=false
       if(@casilla_actual.soy_edificable && (!@casilla_actual.tengo_propietario) && (@casilla_actual.coste<=@saldo))
        coste_compra=@casilla_actual.coste
        titulo=@casilla_actual.asignar_propietario(self)
#        @casilla_actual.titulo.propietario=self
        titulo.casilla=@casilla_actual
       @propiedades<<titulo
        modificar_saldo((-coste_compra))
        puedo_comprar=true
       end
     
      return puedo_comprar
    end
    
    def devolver_carta_libertad
      if(@carta_libertad != nil)
        cl=Sorpresa.new(@carta_libertad.texto,@carta_libertad.valor,@carta_libertad.tipo)
        return cl
      else
        return @carta_libertad
      end
    end
       
    def ir_a_carcel(casilla)
      self.casilla_actual=casilla
      self.encarcelado=true
    end
    
    def modificar_saldo(cantidad)
      @saldo+=cantidad
    end
    
    def obtener_capital
       valor=0;
        @propiedades.each do |i|
            valor+=(i.casilla.num_casas)*(i.casilla.coste)
            valor+=(i.casilla.num_hoteles)*(i.casilla.coste)
             if(i.casilla.esta_hipotecada)
                valor-=i.hipoteca_base
             end
        end
        return (valor+@saldo);   
    end
    
    def obtener_propiedades_hipotecadas(hipotecada)
      tp=Array.new
        @propiedades.each do |t|
            if(hipotecada && t.hipotecada)
              tp<<t
            elsif(!hipotecada && !t.hipotecada)
              tp<<t             
            end
        end
        return tp     
    end
    
    def pagar_cobrar_por_casa_y_hotel(cantidad)
      numero_total=cuantas_casas_hoteles_tengo
      modificar_saldo(numero_total*cantidad)
    end
    
    def pagar_libertad(cantidad)
      tengo_sal=tengo_saldo(cantidad)
      if(tengo_sal)
        modificar_saldo(cantidad)
      end
      return tengo_sal #DUDA
    end
    
    def puedo_edificar_casa(casilla)
      tengo_sal=false
      if(es_de_mi_propiedad(casilla))
        coste_edificar_casa=casilla.get_precio_edificar
        tengo_sal=tengo_saldo(coste_edificar_casa)
      end
      return tengo_sal
    end
    
    def puedo_edificar_hotel(casilla)
      #DUDA REVISAR Y PREGUNTAR
      tengo_sal=false
      if(es_de_mi_propiedad(casilla))
        coste_edificar_hotel=casilla.precio_edificar
        tengo_sal=tengo_saldo(coste_edificar_hotel)
      end
      return tengo_sal
    end
    
    def puedo_hipotecar(casilla)
     return es_de_mi_propiedad(casilla)
    end
    
#NO ESTA EN EL DIAGRAMA   
#    def puedo_pagar_hipoteca(casilla)
#      FALTA
#    end
    
    def puedo_vender_propiedad(casilla)
      return (es_de_mi_propiedad(casilla) && !casilla.esta_hipotecada)
    end
    
    def tengo_carta_libertad
      return (@carta_libertad != nil)
    end
    
    def vender_propiedad(casilla)
      precio_venta=casilla.vender_titulo
      modificar_saldo(precio_venta)
      eliminar_de_mis_propiedades(casilla)
    end
    
    def to_s
      cadena_propiedades=""
      
      @propiedades.each do |i| 
        cadena_propiedades += i.to_s
      end
#      "nombre: #{@nombre}\nencarcelado: #{@encarcelado}\nsaldo: #{@saldo}\ncarta_libertad: #{@carta_libertad.to_s}\ncasilla_actual_jugador: #{@casilla_actual.to_s}\npropiedades:\n #{cadena_propiedades}"
      "nombre: #{@nombre}\nencarcelado: #{@encarcelado}\nsaldo: #{@saldo}\ncarta_libertad: #{@carta_libertad.to_s}\npropiedades:\n #{cadena_propiedades}"
   end
      
    
    def convertirme(fianza)
      esp=Especulador.new(self, fianza)
      return esp
    end
        
    private
    def cuantas_casas_hoteles_tengo
      total=0
      @propiedades.each do |i|
        total+=i.casilla.num_casas
        total+=i.casilla.num_hoteles
      end
      return total
    end

    def eliminar_de_mis_propiedades(casilla)
      @propiedades.delete(casilla.titulo)
    end
    
    def es_de_mi_propiedad(casilla)
      @propiedades.each do |i|
        if i == casilla.titulo
          return true
        end
      end
      return false
    end
    
    def tengo_saldo(cantidad)
       return (@saldo>=cantidad);
    end
    
    
    
    protected
    def pagar_impuestos(cantidad)
      modificar_saldo(-cantidad)
    end

    #Constructor de copia    
    
    
  end
end