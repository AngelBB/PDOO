#encoding: utf-8
require_relative "dado"
require_relative "metodo_salir_carcel"
require_relative "tablero"
require_relative "jugador"
require_relative "casilla"
require_relative "calle"
require "singleton"

module ModeloQytetet
  class Qytetet
    attr_reader :carta_actual, :jugador_actual, :jugadores
    
    include Singleton

    @@MAX_JUGADORES=4
    @@MAX_CARTAS=10
    @@MAX_CASILLAS=20
    @@PRECIO_LIBERTAD=200
    @@SALDO_SALIDA=1000
    
    def initialize
      @carta_actual=Array.new
      @mazo=Array.new
      #atributos del diagrama de clases
      @tablero
      @jugador_actual
      @jugadores =Array.new
      @dado = Dado.instance
      inicializar_cartas_sorpresa
      inicializar_tablero
    end
    
    #metodos del diagrama de clases
    def aplicar_sorpresa
      tiene_propietario=false;
      
      if(@carta_actual.tipo==TipoSorpresa::PAGARCOBRAR)
        @jugador_actual.modificar_saldo(@carta_actual.valor)
      elsif(@carta_actual.tipo==TipoSorpresa::IRACASILLA)
        esCarcel=@tablero.es_casilla_carcel(@carta_actual.valor)
        if(esCarcel)
          encarcelar_jugador;
        else
          nueva_casilla=@tablero.obtener_casilla_numero(@carta_actual.valor)
          tiene_propietario=@jugador_actual.actualizar_posicion(nueva_casilla)
        end
      elsif(@carta_actual.tipo==TipoSorpresa::PORCASAHOTEL)
       @jugador_actual.pagar_cobrar_por_casa_y_hotel(@carta_actual.valor)
      elsif(@carta_actual.tipo==TipoSorpresa::PORJUGADOR)
        @jugadores.each do |j|
          if(j != @jugador_actual)
           j.modificar_saldo(@carta_actual.valor)
           @jugador_actual.modificar_saldo((-@carta_actual.valor))
          end
        end
      elsif(@carta_actual.tipo==TipoSorpresa::CONVERTIRME)
        @jugador_actual.convertirme(@carta_actual.valor)
      end
      
      if(@carta_actual.tipo == TipoSorpresa::SALIRCARCEL)
        @jugador_actual.carta_libertad=@carta_actual
      else
        @mazo<<@carta_actual
      end
      
      return tiene_propietario
    end
        
    def cancelar_hipoteca (casilla)
      a_devolver=casilla.cancelar_hipoteca
      
      if(@jugador_actual.tengo_saldo(a_devolver))
        @jugador_actual.modificar_saldo(-a_devolver)
        return true
      end
      return false
    end
    
    def comprar_titulo_propiedad
      puedo_comprar=@jugador_actual.comprar_titulo
      return puedo_comprar
    end
    
    def edificar_casa(casilla)
      puedo_edificar=false
      if(casilla.soy_edificable)
        se_puede_edificar=casilla.se_puede_edificar_casa
        if(se_puede_edificar)
          puedo_edificar=@jugador_actual.puedo_edificar_casa(casilla)
          if(puedo_edificar)
            coste_edificar_casa=casilla.edificar_casa
            @jugador_actual.modificar_saldo((-coste_edificar_casa))
          end
        end
      end
      return puedo_edificar #DUDA
    end
    
    #Metodo sin ningun diag. REVISAR CON ESPECIAL CUIDADO 
    def edificar_hotel(casilla)
      puedo_edificar=false
      if(casilla.soy_edificable)
        se_puede_edificar=casilla.se_puede_edificar_hotel
        if(se_puede_edificar)
          puedo_edificar=@jugador_actual.puedo_edificar_hotel(casilla)
          if(puedo_edificar)
            coste_edificar_hotel=casilla.edificar_hotel
            @jugador_actual.modificar_saldo((-coste_edificar_hotel))
          end
        end
      end
      return puedo_edificar #DUDA
    end
    
    def hipotecar_propiedad(casilla)
      puedo_hipotecar_propiedad=false;
      if(casilla.soy_edificable && !casilla.esta_hipotecada && @jugador_actual.puedo_hipotecar(casilla))
        cantidad_recibida=casilla.hipotecar
        @jugador_actual.modificar_saldo(cantidad_recibida)
        puedo_hipotecar_propiedad=true
      end
      return puedo_hipotecar_propiedad #DUDA que devolvemos
    end
      
    def inicializar_juego(nombres)
      inicializar_jugadores(nombres)
      inicializar_tablero
      inicializar_cartas_sorpresa
      salida_jugadores
    end
    
    def intentar_salir_carcel(metodo)
      libre=false
      if(metodo== MetodoSalirCarcel::TIRANDODADO)
        valor_dado=@dado.tirar
        libre=(valor_dado>5)
      elsif(metodo==MetodoSalirCarcel::PAGANDOLIBERTAD)
        tengo_saldo=@jugador_actual.pagar_libertad((-@@PRECIO_LIBERTAD))
        libre=tengo_saldo
      end
      
      if(libre)
        @jugador_actual.encarcelado=false
      end
      
      return libre
    end
    
    def jugar
      valor_dado=@dado.tirar
      casilla_posicion=@jugador_actual.casilla_actual
      nueva_casilla=@tablero.obtener_nueva_casilla(casilla_posicion, valor_dado)
      tiene_propietario=@jugador_actual.actualizar_posicion(nueva_casilla)
      
      if(!nueva_casilla.soy_edificable)
        if(nueva_casilla.tipo==TipoCasilla::JUEZ)
          encarcelar_jugador
        elsif(nueva_casilla.tipo==TipoCasilla::SORPRESA)
          @carta_actual=@mazo.at(0)
        end
      end
      return tiene_propietario
    end
    
    def obtener_ranking
      ranking=Hash.new
      capital=0
      @jugadores.each do |j|
        capital=j.obtener_capital
        ranking[j.nombre]=capital
      end
      return ranking
    end
    
    def propiedades_hipotecadas_jugador(hipotecadas)
      tp=Array.new
      tp=@jugador_actual.obtener_propiedades_hipotecadas(hipotecadas)
      cas=Array.new
      tp.each do |i|
        cas<<i.casilla
      end
      return cas
    end
    
    def siguiente_jugador
      pos = 0
      long = @jugadores.length
      for i in 0..long
        if (@jugador_actual == @jugadores.at(i))
          pos = i
        end
      end
      @jugador_actual = @jugadores.at((pos + 1) % long)
      return @jugador_actual
    end
    
    def vender_propiedad(casilla)
      if(casilla.soy_edificable && @jugador_actual.puedo_vender_propiedad(casilla))
        @jugador_actual.vender_propiedad(casilla)
        return true #DUDA
      end
      return false #DUDA
    end
    
    private
    def encarcelar_jugador
      if(!@jugador_actual.tengo_carta_libertad)
        casilla_carcel=@tablero.carcel
        @jugador_actual.ir_a_carcel(casilla_carcel)
      else
        carta=@jugador_actual.devolver_carta_libertad
        @mazo<<carta
      end
    end
      
    def inicializar_cartas_sorpresa
      @mazo=Array.new # Por si acaso ....
      @mazo<< Sorpresa.new("Te ha tocado el bingo ,¡ingresas 2500€!" , 2500,TipoSorpresa::PAGARCOBRAR)
      @mazo<< Sorpresa.new("Se te ha roto el coche ,¡debes pagar 1000€ para arreglarlo!" , 1000,TipoSorpresa::PAGARCOBRAR)
      @mazo<< Sorpresa.new("Te hemos pillado con chanclas y calcetines, lo sentimos, ¡debes ir a la carcel!", 10, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Te echan de menos, ¡debes ir la casilla 13!", 13, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Final de camino, ¡debes ir la casilla 19!", 19, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Vaya te ha llegado la factura del IVA,¡tienes que pagar 500€ por cada cada casa o hotel edificado!", 500, TipoSorpresa::PORCASAHOTEL)
      @mazo<< Sorpresa.new("Han encontrado restos fosiles en tus propiedades,¡recibes 750€ por cada cada casa o hotel edificado!", 750, TipoSorpresa::PORCASAHOTEL)
      @mazo<< Sorpresa.new("Has perdido la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @mazo<< Sorpresa.new("Has ganado la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @mazo<< Sorpresa.new("Un fan anónimo ha pagado tu fianza. Sales de la cárcel", 0, TipoSorpresa::SALIRCARCEL)
      @mazo<< Sorpresa.new("¡Me convierto en Especulador!", 5000, TipoSorpresa::CONVERTIRME)
      @mazo<< Sorpresa.new("¡Me convierto en Especulador!", 3000, TipoSorpresa::CONVERTIRME)
      @mazo.shuffle!
    end
    
    def inicializar_jugadores(nombres)
#      puts 'inicializando jugadores'
      nombres.each do |i|
        @jugadores<<Jugador.new(i)
      end
    end
    
    def inicializar_tablero
      @tablero=Tablero.new
    end
    
    def salida_jugadores
     @jugadores.each do |i| 
       i.casilla_actual=@tablero.obtener_casilla_numero(0)
       i.modificar_saldo(0)
#       puts i.to_s
     end
      
      indexRandom=rand(0..@jugadores.length - 1)
      @jugador_actual=@jugadores.at(indexRandom)
      
    end
    
  #private_class_method :new
  #SOLO PRUEBAS
#    public
#    def mostrar_mazo
#     Mostramos el mazo
#      aux=Array.new
#      @mazo.each do |i|
#       
#          aux<<i
#        
#      end
#      aux
#      
#    end
#    
#     def mostrar_tablero
#      Mostramos el tablero
#      @tablero.to_s
#     end
#    
#     def mostrar_jugadores
#      Mostramos los jugadores
#      aux=Array.new
#      @jugadores.each do |i|
#         aux<<i
#      end
#      aux
#      
#    end

    
      
    end
    
  
    
  end
      
