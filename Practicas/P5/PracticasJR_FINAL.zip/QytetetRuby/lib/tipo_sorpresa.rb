#encoding: utf-8
#Define el tipo enumerado TipoSorpresa que especifica los tipos de sorpresas existentes.
#define los siguientes valores 
module ModeloQytetet
  module TipoSorpresa
      PAGARCOBRAR = :PagarCobrar
      IRACASILLA = :IrACasilla
      PORCASAHOTEL = :PorCasaHotel
      PORJUGADOR = :PorJugador
      SALIRCARCEL = :SalirCarcel
      CONVERTIRME =:Convertirme
  end
end
