#encoding: utf-8

require_relative "tipo_casilla"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Casilla
    
    #Define los consultores básicos para todos los atributos y modificadores básicos de los atributos numHoteles y numCasas. 
    attr_reader :numero_casilla, :coste, :tipo 
   
    def initialize(nc,c,tp)
      @numero_casilla=nc
      @coste=c
      @tipo=tp
    end
    
    def soy_edificable
      return (@tipo == TipoCasilla::CALLE)
    end
    
    def to_s
      "Numero casilla: #{@numero_casilla}, coste: #{@coste}, tipo: #{@tipo}"
    end
  end
end