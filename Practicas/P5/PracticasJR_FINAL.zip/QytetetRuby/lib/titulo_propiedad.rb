#encoding: utf-8
require_relative "jugador"
require_relative "casilla"

module ModeloQytetet
  class TituloPropiedad
    
    #Define los consultores para todos los atributos, el modificador básico del atributo hipotecada
    #GET = READER     SET = WRITER        SI TIENE AMBOS = ACCESSOR
    attr_reader :nombre, :alquiler_base, :factor_revalorizacion, :hipoteca_base, :precio_edificar
    attr_accessor :hipotecada, :propietario, :casilla 
    
    
    def initialize (n,h=false,ab,fr,hb,pe)
      @nombre=n
      @hipotecada=h  
      @alquiler_base=ab
      @factor_revalorizacion=fr
      @hipoteca_base=hb
      @precio_edificar=pe
      #Atributos del diagrama de clases
      @casilla=nil # que es una calle
      @propietario=nil
    end
       
    def to_s
      
      if(!@casilla.nil?)
        "nombre: #{@nombre}, Num.casas: #{@casilla.num_casas} Num.hoteles: #{@casilla.num_hoteles} hipotecada: #{@hipotecada}, alquiler base: #{@alquiler_base}, factor revalorizacion: #{@factor_revalorizacion}, hipoteca base: #{@hipoteca_base}, precio edificar: #{@precio_edificar}\n"
      else
        "nombre: #{@nombre}, hipotecada: #{@hipotecada}, alquiler base: #{@alquiler_base}, factor revalorizacion: #{@factor_revalorizacion}, hipoteca base: #{@hipoteca_base}, precio edificar: #{@precio_edificar}\n"
      end
      
    end
    
    #metodos del diagrama de clases
    def cobrar_alquiler(coste)
      @propietario.modificar_saldo(coste)
    end
    
    def propietario_encarcelado
      return @propietario.encarcelado
    end
    
    def tengo_propietario
      return (@propietario !=nil)
    end
  end
end
