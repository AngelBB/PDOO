#encoding: utf-8

module ModeloQytetet
  class Tablero
    attr_reader :carcel#Consultor para el atributo carcel
    #Constructor sin argumentos
    def initialize
      @casillas=Array.new#Asigna un nuevo ArrayList al atributo casillas
      inicializar
    end
    #método toString().
    def to_s
      cadena=""
      @casillas.each {|v| cadena = cadena + v.to_s}
      cadena
    end
    
    
    def es_casilla_carcel(num_casilla)
      return (@casillas.at(num_casilla).tipo == TipoCasilla::CARCEL)
    end
    
    def obtener_casilla_numero(num_casilla)
      return (@casillas.at(num_casilla))
    end
    
    def obtener_nueva_casilla(casilla, desplazamiento)#Casilla obtenerNuevaCasilla(Casilla casilla, int desplazamiento)
      numeroCasilla = (casilla.numero_casilla + desplazamiento)
      if(@casillas.size() <= numeroCasilla)
        @casillas[numeroCasilla%20]
        return @casillas[numeroCasilla%20]
      else
        return @casillas[numeroCasilla]
      end
    end
     
    
    #Define el método privado inicializar(), que será invocado por el constructor. 
    private
    def inicializar
      #Inicializa el atributo carcel para que apunte a la casilla correspondiente a la cárcel.
      @carcel=Casilla.new(10,0,TipoCasilla::CARCEL)#Para indicar la cárcel, un atributo privado carcel de tipo Casilla.
      @casillas<<Casilla.new(0,0,TipoCasilla::SALIDA)
      @casillas<<Calle.new(1,500,TituloPropiedad.new("San Anton",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(2,0,TipoCasilla::SORPRESA)
      @casillas<<Calle.new(3,1000,TituloPropiedad.new("Recogidas",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Calle.new(4,1500,TituloPropiedad.new("Gran Via",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(5,0,TipoCasilla::JUEZ)
      @casillas<<Calle.new(6,900,TituloPropiedad.new("Pedro Antonio",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(7,0,TipoCasilla::SORPRESA)
      @casillas<<Calle.new(8,1250,TituloPropiedad.new("Camino de Ronda",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Calle.new(9,3000,TituloPropiedad.new("Reyes Catolicos",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<@carcel
      @casillas<<Calle.new(11,2000,TituloPropiedad.new("Avd. Constitucion",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Calle.new(12,1200,TituloPropiedad.new("Avd. de Andalucia",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(13,0,TipoCasilla::PARKING)
      @casillas<<Calle.new(14,3000,TituloPropiedad.new("Mesones",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(15,0,TipoCasilla::SORPRESA)
      @casillas<<Calle.new(16,1500,TituloPropiedad.new("San Juan de Dios",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Calle.new(17,1750,TituloPropiedad.new("Arabial",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.new(18,0,TipoCasilla::IMPUESTO)
      @casillas<<Calle.new(19,2500,TituloPropiedad.new("Severo Ochoa",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
    end
  end
end
