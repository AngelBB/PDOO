/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import GUIQytetet.Dado;
import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Collections.shuffle;
import java.util.Random;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;



/**
 *
 * @author abarrilao
 */
public class Qytetet {
    
    //Static significa metdo de clase y se representa en el diagrama de clases con un subrayado.
    public static int MAX_JUGADORES=4;
    static int MAX_CARTAS=10;
    static int MAX_CASILLAS=20;
    static int PRECIO_LIBERTAD=200;
    static int SALDO_SALIDA=1000;
    
    //Relaciones con las demas clases
    Sorpresa cartaActual;
    ArrayList<Sorpresa> mazo=new ArrayList<Sorpresa>(MAX_CARTAS);//Declaramos con el tope la capacidad de nuestro mazo
    ArrayList<Jugador>jugadores=new ArrayList<Jugador>(MAX_JUGADORES);
    Jugador jugadorActual;
    Tablero tablero;
    Dado dado;
   
    
    private Qytetet() {
        
    }
    
    private static class QytetetHolder {
        private static final Qytetet INSTANCE = new Qytetet();
    }
    
    public static Qytetet getInstance() {
        return QytetetHolder.INSTANCE;
    }
    
    
    
    //metodos del diagrama de clases
    public boolean aplicarSorpresa(){
        boolean tienePropietario=false;
        
        if(cartaActual.getTipo()==TipoSorpresa.PAGARCOBRAR){
            jugadorActual.modificarSaldo(cartaActual.getValor());
        }else if(cartaActual.getTipo()==TipoSorpresa.IRACASILLA){
            boolean esCarcel=tablero.esCasillaCarcel(cartaActual.getValor());
            if(esCarcel){
                this.encarcelarJugador();
            }else{
                Casilla nuevaCasilla=tablero.obtenerCasillaNumero(cartaActual.getValor());
                tienePropietario=jugadorActual.actualizarPosicion(nuevaCasilla);
            }
        }else if(cartaActual.getTipo()==TipoSorpresa.PORCASAHOTEL){
            jugadorActual.pagarCobrarPorCasaYHotel(cartaActual.getValor());
        }else if(cartaActual.getTipo()==TipoSorpresa.PORJUGADOR){
            for (Jugador j :jugadores){
                if(j!=jugadorActual){
                    j.modificarSaldo(cartaActual.getValor());
                    jugadorActual.modificarSaldo((-(cartaActual.getValor())));
                }
            }
        }else if(cartaActual.getTipo()==TipoSorpresa.CONVERTIRME){
            //Obtenemos el jugador actual , lo convertimos y sustituimos en el array de jugadores y en el jugador actual.
            Jugador jugadorAux=(Jugador)jugadorActual.convertirme(cartaActual.getValor());     
            int index=jugadores.indexOf(jugadorActual);
            jugadores.remove(index);
            jugadores.add(jugadorAux);
            ArrayList<TituloPropiedad> tp=jugadorActual.getPropiedades();
            for(TituloPropiedad t:tp){
                t.setPropietario(jugadorAux);
            }
            jugadorActual=jugadorAux;
        }
        
        if(cartaActual.getTipo() == TipoSorpresa.SALIRCARCEL){
            jugadorActual.setCartaLibertad(cartaActual);       
        }else{
            mazo.add(cartaActual);
        }
    
        return tienePropietario;
    }
    public boolean cancelarHipoteca(Calle casilla){
        int aDevolver=casilla.cancelarHipoteca();
        if(jugadorActual.tengoSaldo(aDevolver)){
            jugadorActual.modificarSaldo(-aDevolver);
            return true;
        }
        return false;
    }
    public boolean comprarTituloPropiedad(){
        boolean puedoComprar=jugadorActual.comprarTitulo();
        return puedoComprar;
    }
    public boolean edificarCasa(Calle casilla){
        boolean puedoEdificar = false;
        if(casilla.soyEdificable()){
            boolean sePuedeEdificar=casilla.sePuedeEdificarCasa();
            if(sePuedeEdificar){
                puedoEdificar= jugadorActual.puedoEdificarCasa(casilla);
                if(puedoEdificar){
                   int costeEdificarCasa=casilla.edificarCasa();
                   jugadorActual.modificarSaldo((-costeEdificarCasa));
                }
            }
        }
        return puedoEdificar; 
    }
    
 
   public boolean edificarHotel(Calle casilla){
       boolean puedoEdificar = false;
        if(casilla.soyEdificable()){
            boolean sePuedeEdificar=casilla.sePuedeEdificarHotel();
            if(sePuedeEdificar){
                puedoEdificar= jugadorActual.puedoEdificarHotel(casilla);
                if(puedoEdificar){
                   int costeEdificarHotel=casilla.edificarHotel();
                   jugadorActual.modificarSaldo((-costeEdificarHotel));
                }
            }
        }
        return puedoEdificar;
   }
   public Sorpresa getCartaActual(){
       return cartaActual;
   }
   public Jugador getJugadorActual(){
       return jugadorActual;
   }
    public boolean hipotecarPropiedad(Calle casilla){
        boolean puedoHipotecarPropiedad=false;
        if(casilla.soyEdificable() && !casilla.estaHipotecada() && jugadorActual.puedoHipotecar(casilla)){
            int cantidadRecibida=casilla.hipotecar();
            jugadorActual.modificarSaldo(cantidadRecibida);
            puedoHipotecarPropiedad=true;
        }
        return puedoHipotecarPropiedad; 
    }
    public void inicializarJuego(ArrayList<String> nombres){
      this.inicializarJugadores(nombres);
      this.inicializarTablero();
      this.inicializarCartasSorpresa();
      this.salidaJugadores();
    }
   public boolean intentarSalirCarcel(MetodoSalirCarcel metodo){
        boolean libre=false;
        if(metodo==MetodoSalirCarcel.TIRANDODADO){
            dado = GUIQytetet.Dado.getInstance();
            int valorDado =dado.nextNumber();
            libre=(valorDado>5);
        }else if(metodo==MetodoSalirCarcel.PAGANDOLIBERTAD){
            boolean tengoSaldo=jugadorActual.pagarLibertad((-Qytetet.PRECIO_LIBERTAD));
            libre=tengoSaldo;
        }
        if(libre){
            jugadorActual.setEncarcelado(false);
        }
        return libre;
   }
   public boolean jugar(){
       dado = GUIQytetet.Dado.getInstance();
       int valorDado=dado.nextNumber();
       Casilla casillaPosicion=jugadorActual.getCasillaActual();
       Casilla nuevaCasilla=tablero.obtenerNuevaCasilla(casillaPosicion, valorDado);
       boolean tienePropietario=jugadorActual.actualizarPosicion(nuevaCasilla);
       
       if(!nuevaCasilla.soyEdificable()){
           if(nuevaCasilla.getTipo()==TipoCasilla.JUEZ){
               this.encarcelarJugador();
           }else if(nuevaCasilla.getTipo()==TipoCasilla.SORPRESA){
               cartaActual=mazo.get(0);
           }
        }
   
       return tienePropietario;
    }
   public LinkedHashMap<String,Integer> obtenerRanking(){
       HashMap<String,Integer> ranking=new HashMap<String,Integer>(); 
       LinkedHashMap<String,Integer> rankingOrdenado=new LinkedHashMap(); 
       int capital;
       
       for(Jugador j:jugadores){
           capital=j.obtenerCapital();
           ranking.put(j.getNombre(),capital);
       }
       rankingOrdenado=ordenarRanking(ranking);//Ordenamos por orden de dinero
       
       return rankingOrdenado;
   }
    //Para poner el ranking ordenado
    private LinkedHashMap ordenarRanking(HashMap map) { 
        LinkedHashMap<String,Integer> lhm= new LinkedHashMap();
        Object[] a = map.entrySet().toArray();
        Arrays.sort(a, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Map.Entry<String, Integer>) o2).getValue()
                           .compareTo(((Map.Entry<String, Integer>) o1).getValue());
            }
        });
        for (Object e : a) {
            lhm.put(((Map.Entry<String, Integer>) e).getKey(), ((Map.Entry<String, Integer>) e).getValue());
        }
        return lhm;
    }
    public ArrayList<Calle> propiedadesHipotecadasJugador(boolean hipotecadas){
        ArrayList<TituloPropiedad> tp=jugadorActual.obtenerPropiedadesHipotecadas(hipotecadas);
        ArrayList<Calle> cas=new ArrayList();
        for(TituloPropiedad t:tp){
            cas.add(t.getCasilla());
        }
        return cas;
    }
    
    public Jugador siguienteJugador(){
        int pos= jugadores.indexOf(jugadorActual);
        jugadorActual=(Jugador)jugadores.get((pos+1)%jugadores.size());
        
        return jugadorActual;
    }   
    
          
    public boolean venderPropiedad(Calle casilla){
        if(casilla.soyEdificable() && jugadorActual.puedoVenderPropiedad((Calle)casilla)){
            jugadorActual.venderPropiedad((Calle)casilla);
            return true;
        }
        return false;
    }
   private void encarcelarJugador(){
       if(!jugadorActual.tengoCartaLibertad()){
           OtraCasilla casillaCarcel=tablero.getCarcel();
           jugadorActual.irACarcel(casillaCarcel);
       }else{
           Sorpresa carta=jugadorActual.devolverCartaLibertad();
           mazo.add(carta);
       }
   }
    private void inicializarCartasSorpresa(){
        mazo.add(new Sorpresa ("Te ha tocado el bingo ,¡ingresas 2500€!" , 2500,TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa ("Se te ha roto el coche ,¡debes pagar 1000€ para arreglarlo!" , 1000,TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa ("Te hemos pillado con chanclas y calcetines, lo sentimos, ¡debes ir a la carcel!", tablero.getCarcel().getNumeroCasilla(), TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa ("Te echan de menos, ¡debes ir la casilla 13!", 13, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa ("Final de camino, ¡debes ir la casilla 19!", 19, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa ("Vaya te ha llegado la factura del IVA,¡tienes que pagar 500€ por cada cada casa o hotel edificado!", -500, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa ("Han encontrado restos fosiles en tus propiedades,¡recibes 750€ por cada cada casa o hotel edificado!", 750, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa ("Has perdido la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", -1000,TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa ("Has ganado la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa ("Un fan anónimo ha pagado tu fianza. Sales de la cárcel", 0, TipoSorpresa.SALIRCARCEL));   
        mazo.add(new Sorpresa ("¡Me convierto en Especulador!", 3000, TipoSorpresa.CONVERTIRME));   
        mazo.add(new Sorpresa ("¡Me convierto en Especulador!", 5000, TipoSorpresa.CONVERTIRME));   
        shuffle(mazo);
    }
   private void inicializarJugadores(ArrayList<String> nombres){
        for(String s:nombres){
            jugadores.add(new Jugador(s));
        }
    }
   private void inicializarTablero(){
       tablero=new Tablero();
   }
   private void salidaJugadores(){
        for(Jugador j:jugadores){
           j.setCasillaActual(tablero.obtenerCasillaNumero(0));
           j.modificarSaldo(0);
        }
        
        Random randomGenerator = new Random();
        int index =randomGenerator.nextInt(jugadores.size());
        jugadorActual=jugadores.get(index);
   }
     
    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public ArrayList<Sorpresa> getMazo() {
        return mazo;
    }

    public Tablero getTablero() {
        return tablero;
    }
}
    
    
    
