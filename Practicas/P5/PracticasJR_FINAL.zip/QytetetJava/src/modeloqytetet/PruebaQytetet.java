/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import java.util.ArrayList;

/**
 *
 * @author jairoabrilmoya
 */
public class PruebaQytetet {

    /**
     * @param args the command line arguments
     */
    /*crea los objetos de la clase Sorpresa que se corresponden con
    las cartas sorpresa */
    
   /* Define un atributo de clase de ámbito privado de nombre mazo y de tipo ArrayList
    donde almacenar los objetos Sorpresa. Los objetos ArrayList se declaran y construyen de 
    la siguiente manera
    */
    private static ArrayList<Sorpresa> mazo = new ArrayList();
    
    /*En la clase PruebaQytetet crea e inicializa un atributo de clase privado tablero, de tipo
    Tablero.*/
    private static Tablero tablero=new Tablero();
    
    /*Define un método de clase privado inicializarSorpresas() para que se creen e incluyan
    en el mazo todos los objetos sorpresa 
    */
    private static void inicializarSorpresas(){
        mazo.add(new Sorpresa ("Te ha tocado el bingo ,¡ingresas 2500€!" , 2500,TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa ("Se te ha roto el coche ,¡debes pagar 1000€ para arreglarlo!" , 1000,TipoSorpresa.PAGARCOBRAR));
        /*Como ya tenemos definido en el tablero la posición de la cárcel, modifica en el método
         inicializarSorpresas() de la clase PruebaQytetet la creación de la carta sorpresa que
        envía al jugador a la cárcel, de forma que el número de casilla */
        mazo.add(new Sorpresa ("Te hemos pillado con chanclas y calcetines, lo sentimos, ¡debes ir a la carcel!", tablero.getCarcel().getNumeroCasilla(), TipoSorpresa.IRACASILLA));
        
        mazo.add(new Sorpresa ("Te echan de menos, ¡debes ir la casilla 13!", 13, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa ("Final de camino, ¡debes ir la casilla 19!", 19, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa ("Vaya te ha llegado la factura del IVA,¡tienes que pagar 500€ por cada cada casa o hotel edificado!", -500, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa ("Han encontrado restos fosiles en tus propiedades,¡recibes 750€ por cada cada casa o hotel edificado!", 750, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa ("Has perdido la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", -1000,TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa ("Has ganado la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa ("Un fan anónimo ha pagado tu fianza. Sales de la cárcel", 0, TipoSorpresa.SALIRCARCEL));   
    
    }
    
    /*Método 1: Sorpresas que tienen un valor mayor que 0.*/
 
 
    private static ArrayList<Sorpresa> mayorQueCero(){
        ArrayList<Sorpresa> aux=new ArrayList();
        for(Sorpresa i:mazo){
            if(i.getValor()>0){
                aux.add(i);
            }
        
        }
        return aux;
    }
            
     /*Método 2: Sorpresas de TipoSorpresa IRACASILLA.*/       
            
    private static ArrayList<Sorpresa> irACasilla(){
        ArrayList<Sorpresa> aux=new ArrayList();
        for(Sorpresa i:mazo){
            if(i.getTipo()==TipoSorpresa.IRACASILLA){
                aux.add(i);
            }
        
        }
        return aux;
    }
     /*Método 3: Sorpresas del TipoSorpresa especificado en/ el argumento del método*/
    private static ArrayList<Sorpresa> especifico(TipoSorpresa ts){
        ArrayList<Sorpresa> aux=new ArrayList();
        for(Sorpresa i:mazo){
            if(i.getTipo()==ts){
                aux.add(i);
            }
        }
        return aux;
    }        
            

   
    public static void main(String[] args) {
//        /*En el método main() de la clase PruebaQytetet invoca al método inicializarSorpresas() y
//        muestra el contenido del mazo usando el método toString().
//        */
//        PruebaQytetet.inicializarSorpresas();
//        
//        for(Sorpresa s: mazo){
//            System.out.println(s.toString());
//        }
//        
//        PruebaQytetet.inicializarSorpresas();
//        ArrayList<Sorpresa> mazoaux1 =new ArrayList(PruebaQytetet.mayorQueCero());
//        ArrayList<Sorpresa> mazoaux2 =new ArrayList(PruebaQytetet.irACasilla());
//        ArrayList<Sorpresa> mazoaux3 =new ArrayList(PruebaQytetet.especifico(TipoSorpresa.SALIRCARCEL));
//        
//        System.out.println("Mayor que cero");
//        for(Sorpresa i: mazoaux1){
//            System.out.println(i.toString());
//        }
//        
//        System.out.println("Ir a casilla");
//        for(Sorpresa i: mazoaux2){
//            System.out.println(i.toString());
//        }
//         
//        System.out.println("Especifico");
//        for(Sorpresa i: mazoaux3){
//            System.out.println(i.toString());
//        }
//        
//        System.out.println(tablero.toString());
        

//ArrayList<String> nombres=new ArrayList();
//
//nombres.add("Manolo");
//nombres.add("Juan");
//
//Qytetet qt=Qytetet.getInstance();
//
//qt.inicializarJuego(nombres);
//qt.mostrar_jugadores();
//qt.mostrar_mazo();
//qt.mostrar_tablero();


    }
    
}
