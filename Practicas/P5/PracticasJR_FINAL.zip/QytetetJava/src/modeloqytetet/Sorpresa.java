/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author jairoabrilmoya
 * Define en modeloqytetet la clase Sorpresa con los siguientes atributos de visibilidad
privada
 */
/*Esta clase  representa a las cartas Sorpresa */
public class Sorpresa {
    private String texto;
    private TipoSorpresa tipo;
    private int valor;//El valor de la carta puede hacer referencia a dinero o posicion del tablero.
    
    /*Añade el constructor de la clase con visibilidad pública asegurándote de que se
    inicializan correctamente los atributos
    */
    public Sorpresa(String txt, int val, TipoSorpresa tip){
        this.texto=txt;
        this.valor=val;
        this.tipo=tip;
    }
     /*Define con visiblidad de paquete los consultores de los atributos definidos
        anteriormente, cuya funcionalidad es devolver el valor de los mismos.   
        */
    String getTexto(){
        return this.texto;
    }
    
    TipoSorpresa getTipo(){
        return this.tipo;
    }
    
    int getValor(){
        return this.valor;
    }
    /*Define el método toString() en la clase Sorpresa. Éste método devuelve un String con el
      estado del objeto correspondiente. Utiliza la siguiente implementación
    */
    @Override
    public String toString() {
        return "texto: " + texto + ", valor: " + Integer.toString(valor) + ", tipo: " + tipo;
    } 
}