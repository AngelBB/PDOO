/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author AngelBarrilaoB.
 * 
 * 
 */
public abstract class Casilla {
    
    protected int numeroCasilla;
    protected TipoCasilla tipo;
    protected int coste;
    
    public Casilla(int numeroCasilla, int coste, TipoCasilla tipo) {
        this.coste=coste;
        this.numeroCasilla = numeroCasilla;
        this.tipo = tipo;
    }
    
    public int getNumeroCasilla() {
        return numeroCasilla;
    }

    public TipoCasilla getTipo() {
        return tipo;
    }
    
    int getCoste() {
        return coste;
    }
   
    boolean soyEdificable(){
        return (tipo == TipoCasilla.CALLE);
    }
    /*Define el método toString(). Asegúrate de que si las casillas tienen título de propiedad,
    éste se incluya adecuadamente*/
    @Override
    public String toString() {
        return "Numero casilla: " + numeroCasilla + ", tipo: " + tipo;
    }
    
    
    //Metodos del diagrama de clases
    private void asignarTituloPropiedad(){}
}
