/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author AngelBarrilaoB.
 */
public class Especulador extends Jugador{
    
    static int FactorEspeculador = 2;
    private int fianza;
    
  
    protected Especulador(Jugador jugador,int fianza){
        super(jugador);
        this.fianza=fianza;
    }
    
    @Override
    protected void pagarImpuestos(int cantidad){
        super.pagarImpuestos((cantidad/2));
    }
    
    @Override
    protected void irACarcel(OtraCasilla casilla){
        super.irACarcel(casilla);
        boolean estado=pagarFianza(fianza);
        if(!estado){
            setEncarcelado(false);
        }
    }
    
    @Override
    protected Especulador convertirme(int fianza){
        this.fianza=fianza;
        return this;
    }
    
    private boolean pagarFianza(int cantidad){
        boolean tengoSaldo=this.tengoSaldo(cantidad);
        if(tengoSaldo){
            this.modificarSaldo(cantidad);
        }
        return tengoSaldo; 
    }

    @Override
    public String toString() {
        return super.toString()+"fianza: "+fianza+"\n";
    }
}
