/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author AngelBarrilaoB.
 */
public class Calle extends Casilla {
    private TituloPropiedad titulo;
    private int numHoteles;
    private int numCasas;
    
    public Calle(int numeroCasilla, int coste, TituloPropiedad tp) {
        super(numeroCasilla, coste,TipoCasilla.CALLE);
        this.titulo=tp;
    }

    
    int getPrecioEdificar(){
        return titulo.getPrecioEdificar();
    }
    /*◦ Define el modificador básico setTituloPropiedad() como método privado.*/
    private void setTitulo(TituloPropiedad titulo){
        this.titulo=titulo;
    }
    TituloPropiedad asignarPropietario(Jugador jugador){
        titulo.setPropietario(jugador);
        return titulo;
    }
    int calcularValorHipoteca(){
        int hipotecaBase=titulo.getHipotecaBase();
        hipotecaBase=(int) (hipotecaBase + ((numCasas * 0.5 * hipotecaBase) + (numHoteles * hipotecaBase)));
        return hipotecaBase;
    }
    int cancelarHipoteca(){
        int devolver=0;
        if(this.estaHipotecada()){
            titulo.setHipotecada(false);
            devolver=((int)((calcularValorHipoteca()*0.10)+calcularValorHipoteca()));
        }
        return devolver;
    }
    int cobrarAlquiler(){
        int costeAlquilerBase=titulo.getAlquilerBase();
        costeAlquilerBase+= ((numCasas* 0.5) + (numHoteles *2));
        titulo.cobrarAlquiler(costeAlquilerBase);
        return costeAlquilerBase; 
    }
    int edificarCasa(){
        this.setNumCasas(numCasas+1);
        int costeEdificarCasa=titulo.getPrecioEdificar();
        return costeEdificarCasa;   
    }
    int edificarHotel(){
        this.setNumCasas(0);
        int costeEdificarHotel=titulo.getPrecioEdificar();
        return costeEdificarHotel; 
    }
    boolean estaHipotecada(){
        return (titulo.getHipotecada());
    }
    int hipotecar(){
        titulo.setHipotecada(true);
        int cantidadRecibida=this.calcularValorHipoteca();
        return cantidadRecibida;
    }
    boolean propietarioEncarcelado(){
        return titulo.propietarioEncarcelado();
    }
    boolean sePuedeEdificarCasa(){
        return (numCasas<4);
    }
    boolean sePuedeEdificarHotel(){
        return (numHoteles<4 && numCasas==4);
    
    }
    
    public boolean tengoPropietario(){
        return (titulo.tengoPropietario());
    }
    int venderTitulo(){
        titulo.setPropietario(null);
        this.setNumCasas(0);
        this.setNumHoteles(0);
        int precioCompra=coste+(numCasas+numHoteles)* titulo.getPrecioEdificar();
        int precioVenta=(int) (precioCompra+titulo.getFactorRevalorizacion()* precioCompra);
        return precioVenta;
    }
    
    //Practica 4
    public  boolean sePuedeEdificarCasa(int factorEspeculador){
        int numCasas_factor=numCasas*factorEspeculador;
        return (numCasas < numCasas_factor);
    
    }
    public  boolean sePuedeEdificarHotel(int factorEspeculador){
        int numHoteles_factor=numHoteles*factorEspeculador;
        int numCasas_factor=numCasas*factorEspeculador;
        return (numHoteles < numHoteles_factor && numCasas==numCasas_factor);
    }
    //-----
    
    int getNumHoteles() {
        return numHoteles;
    }
    int getNumCasas() {
        return numCasas;
    }
    public TituloPropiedad getTitulo() {
        return titulo;
    }    
    void setNumHoteles(int nuevoNumero) {
        this.numHoteles = nuevoNumero;
    }
    void setNumCasas(int nuevoNumero) {
        this.numCasas = nuevoNumero;
    }
    
    @Override
    public String toString() {
        //return  (super.toString()+" ,coste: " + coste + ", numHoteles: " + numHoteles + ", numCasas: " + numCasas + ", titulo: "+titulo.toString());
        return  (super.toString()+" nombre: "+titulo.getNombre()+" ,coste: " + coste + ", numHoteles: " + numHoteles + ", numCasas: " + numCasas + "\n-TITULO: "+titulo.toString());
    }
}
