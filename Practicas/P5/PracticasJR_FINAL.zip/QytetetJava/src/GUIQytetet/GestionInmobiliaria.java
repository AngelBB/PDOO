/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIQytetet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modeloqytetet.Calle;
import modeloqytetet.Qytetet;
import modeloqytetet.TituloPropiedad;

/**
 *
 * @author AngelBarrilaoB.
 */
public class GestionInmobiliaria extends javax.swing.JDialog {

    /**
     * Creates new form GestionInmobiliaria
     * @param parent
     * @param modal
     * @param juego
     */
    private Qytetet juego;
    
    public GestionInmobiliaria(java.awt.Frame parent, boolean modal,Qytetet qt) {
        super(parent, modal);
        initComponents();
        juego=qt;
        borrarComboBoxes();//Para borrar los items por defecto (seguro que hay una manera mas elegante)
        inicializarCBAccion();
        inicializarPropiedades(qt);
        actualizarJugadorActual();
                
        /*Asignamos evento para controlar cuando seleccionemos una propiedad 
        si la propiedad esta hipotecada modificaremos el combo box y mostraremos la opcion "cancelar hipoteca"*/
        jcbPropiedad.addActionListener (new ActionListener () {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Si la prop. esta hipotecada
                if(tieneHipoteca(jcbPropiedad.getSelectedItem().toString())){
                    borrarItemAcciones("Hipotecar");//Borramos la opcion hipotecar
                    jcbAccion.addItem("Cancelar hipoteca");
                }else{
                    //Si no esta hipotecada
                    borrarItemAcciones("Cancelar hipoteca");//Borramos la opc. cancelar hipoteca
                    jcbAccion.addItem("Hipotecar");
                }
            }
        });
    }
    
    private void actualizarJugadorActual(){
        jlJugadorActual.setText("Jugador actual: "+juego.getJugadorActual().getNombre());
    }
    
    private void borrarComboBoxes(){
        jcbAccion.removeAllItems();
        jcbPropiedad.removeAllItems();
    }
    
    public void borrarItemAcciones(String accion){
        for (int i = 0; i < jcbAccion.getItemCount(); i++) {
            Object item = jcbAccion.getItemAt(i);
            if(item.toString().equals(accion)){
                jcbAccion.removeItemAt(i);
            }
        }
    }
    
    boolean tieneHipoteca(String nombreCalle){
        ArrayList<Calle> prop_hipotecada=juego.propiedadesHipotecadasJugador(true);
        for(Calle c:prop_hipotecada){
            if(c.getTitulo().getNombre().equals(nombreCalle))
                return true;
        }
        return false;
    }
    
    private void inicializarCBAccion(){
        (this.jcbAccion).addItem("Edificar casa");
        (this.jcbAccion).addItem("Edificar hotel");
        (this.jcbAccion).addItem("Vender");
        (this.jcbAccion).addItem("Hipotecar");
    }
    
    private void inicializarPropiedades(Qytetet qt){
        ArrayList<TituloPropiedad> propiedades=qt.getJugadorActual().getPropiedades();
        for(TituloPropiedad tp:propiedades){
            (this.jcbPropiedad).addItem(tp.getNombre());
        }
    }
    
    private Calle obtenerCalle(String nombreCalle){
       Calle casilla=null;
        ArrayList<TituloPropiedad> propiedades=juego.getJugadorActual().getPropiedades();
        for(TituloPropiedad tp:propiedades){
            if(tp.getNombre().equals(nombreCalle))
                casilla= tp.getCasilla();
        }
        return casilla;
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbBoton1 = new javax.swing.JButton();
        jcbPropiedad = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jcbAccion = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jlJugadorActual = new javax.swing.JLabel();
        jbAplicar = new javax.swing.JButton();

        jbBoton1.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jbBoton1.setText("APLICAR");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jcbPropiedad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jcbPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbPropiedadActionPerformed(evt);
            }
        });

        jLabel1.setText("Escoge la propiedad: ");

        jLabel2.setText("Escoge la accion:");

        jcbAccion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Gestión Inmobiliaria");

        jlJugadorActual.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlJugadorActual.setText("Jugador actual: ");

        jbAplicar.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jbAplicar.setText("APLICAR");
        jbAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAplicarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jlJugadorActual)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jcbAccion, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(42, 57, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(16, 16, 16))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jcbPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jbAplicar, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jlJugadorActual)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jcbPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcbAccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jbAplicar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jcbPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbPropiedadActionPerformed
        
    }//GEN-LAST:event_jcbPropiedadActionPerformed

    private void jbAplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAplicarActionPerformed
        Calle casilla;
        String propiedad = jcbPropiedad.getSelectedItem().toString();
        int opc=jcbAccion.getSelectedIndex();
        casilla=obtenerCalle(propiedad);//Obtenemos la calle correcpondiente
         
        switch (opc){
            case 0: 
                if(juego.edificarCasa(casilla))
                    JOptionPane.showMessageDialog(this,"Casa edificada");
                else
                    JOptionPane.showMessageDialog(this,"Casa NO edificada");
                break;
            case 1:
                if(juego.edificarHotel(casilla))
                    JOptionPane.showMessageDialog(this,"Hotel edificado");
                else
                    JOptionPane.showMessageDialog(this,"Hotel NO edificado");
                break;
            case 2: 
               if(juego.venderPropiedad(casilla))
                    JOptionPane.showMessageDialog(this,"Propiedad vendida");
                else
                    JOptionPane.showMessageDialog(this,"Propiedad NO vendida");
                break;
            case 3: 
                 if(juego.hipotecarPropiedad(casilla))
                    JOptionPane.showMessageDialog(this,"Propiedad hipotecada");
                 else
                    JOptionPane.showMessageDialog(this,"Propiedad NO hipotecada");
                break;
            case 4: 
               if(juego.cancelarHipoteca(casilla))
                    JOptionPane.showMessageDialog(this,"hipoteca cancelada");
                else
                    JOptionPane.showMessageDialog(this,"hipoteca NO cancelada");
                break;
            default: JOptionPane.showMessageDialog(this,"Error en metodo gestion inmobiliaria");
                break;
        }
    }//GEN-LAST:event_jbAplicarActionPerformed

    public Qytetet getJuegoActual(){
        this.setVisible(true);
        return juego;
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton jbAplicar;
    private javax.swing.JButton jbBoton1;
    private javax.swing.JComboBox<String> jcbAccion;
    private javax.swing.JComboBox<String> jcbPropiedad;
    private javax.swing.JLabel jlJugadorActual;
    // End of variables declaration//GEN-END:variables
}
