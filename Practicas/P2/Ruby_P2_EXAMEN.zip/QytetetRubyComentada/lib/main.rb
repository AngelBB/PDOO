# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative "jugador"

module ModeloQytetet
  class Main
    def initialize

    end
    
    
    def self.probar_examen
      dinero = Array.new
      dinero<<Billete.new("verde", TipoBillete::DE10)
      dinero<<Billete.new("amarillo", TipoBillete::DE100)
      
      j=Jugador.crear("Paco",dinero)
      j.nuevo_billete("verde", TipoBillete::DE10)
      puts j.consultar_saldo_billetes
      puts j.to_s
    end      
    
    
  end
  
  
  
  
  
end