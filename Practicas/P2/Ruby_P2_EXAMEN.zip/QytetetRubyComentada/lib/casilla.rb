#encoding: utf-8

require_relative "tipo_casilla"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Casilla
    
    #Define los consultores básicos para todos los atributos y modificadores básicos de los atributos numHoteles y numCasas. 
    attr_reader :numero_casilla, :coste, :tipo 
    attr_accessor :num_hoteles, :num_casas , :titulo
    
    def initialize(nc,c,nh=0,nca=0,tc,tit)
      @numero_casilla=nc
      @coste=c
      @num_hoteles=nh
      @num_casas=nca
      @tipo=tc
      @titulo=tit
    end
  
    
    
    def asignar_propietario(jugador)
      
    end
    
    def calcular_valor_hipoteca
      
    end
    
    def cancelar_hipoteca
      
    end
    
    def cobrar_alquiler
      
    end
    
    def edificar_casa
      
    end
    
    def edificar_hotel
      
    end
    
    def esta_hipotecada
      
    end
    
    def get_coste_hipoteca
      
    end
    
    def get_precio_edificar
      
    end
    
    def hipotecar
      
    end
    
    def precio_total_comprar
      
    end
    
    def propietario_encarcelado
      
    end
    
    def se_puede_edificar_casa
      
    end
    
    def se_puede_edificar_hotel
      
    end
    
    def soy_edificable
      
    end
    
    def tengo_propietario
      
    end
    
    def vender_titulo
      
    end
       
    #Define dos constructores: uno para las casillas que no son de tipo calle
    def self.casilla_no_calle(nc,c,tc)
      if(tc != TipoCasilla::CALLE )
        self.new(nc,c,0,0,tc,nil)#CUIDADO CON LOS NULL
      end
    end
   
    # otro para las que son de este tipo y tienen título de propiedad.
    def self.casilla_si_calle(nc,c,tp)
      if( !tp.nil?)
        self.new(nc,c,0,0,tp)
      end

    end
    
    def to_s
      if (@titulo.nil?)
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad: - \n"
      else
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad: #{@titulo.to_s}"
      end
    end
        
    #Define el modificador básico setTituloPropiedad() como método privado
    private :titulo
    
    private
    def asignar_titulo_propiedad

    end
      
  end
end