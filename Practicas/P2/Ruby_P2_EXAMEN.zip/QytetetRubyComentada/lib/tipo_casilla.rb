#encoding: utf-8
#Define el tipo enumerado TipoCasilla que especifica los tipos de sorpresas existentes.
#define los siguientes valores 
module ModeloQytetet
   module TipoCasilla
      SALIDA = :Salida
      CALLE = :Calle
      SORPRESA = :Sorpresa
      CARCEL = :Carcel
      JUEZ = :Juez
      IMPUESTO = :Impuesto
      PARKING = :Parking
  end
end
