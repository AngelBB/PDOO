# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative "sorpresa"
require_relative "casilla"
require_relative "titulo_propiedad"
require_relative "billete"

module ModeloQytetet
  class Jugador
    attr_writer :carta_libertad 
    attr_accessor :encarcelado, :casilla_actual
        
    def initialize(n,b)
      @encarcelado=false
      @nombre=n
      @saldo=7500
      @carta_libertad
      @propiedades=Array.new
      @casilla_actual
      @misBilletes=b
    end
    
    def tengo_propiedades
      
    end
    
    def actualizar_posicion(casilla)
      
    end
    
    def comprar_titulo
      
    end
    
    def devolver_carta_libertad
      
    end
       
    def ir_a_carcel(casilla)
      
    end
    
    def modificar_saldo(cantidad)
      
    end
    
    def obtener_capital
      
    end
    
    def obtener_propiedades_hipotecadas(hipotecada)
      
    end
    
    def pagar_cobrar_por_casa_y_hotel(cantidad)
      
    end
    
    def pagar_libertad(cantidad)
      
    end
    
    def puedo_edificar_casa(casilla)
            
    end
    
    def puedo_edificar_hotel(casilla)
      
    end
    
    def puedo_hipotecar(casilla)
      
    end
    
    def puedo_pagar_hipoteca(casilla)
      
    end
    
    def puedo_vender_propiedad(casilla)
      
    end
    
    def tengo_carta_libertad
      
    end
    
    def vender_propiedad(casilla)
      
    end
      
    private
    def cuantas_casas_hoteles_tengo
      
    end

    def eliminar_de_mis_propiedades(casilla)
  
    end
    
    def es_de_mi_propiedad(casilla)
      
    end
    
    def tengo_saldo
      
    end
    
    
    
    #EXAMEN
    public
#    def crear(n,b)
#      @nombre=n
#      @misBilletes=b
#      Jugador.new(n)
#    end

    def self.crear(n,b)
      @nombre=n
      @misBilletes=b
      Jugador.new(n,b)
    end
    
    def consultar_saldo_billetes
      total=0
      @misBilletes.each do |i|
        if(i.tipo == TipoBillete::DE10)
          total+=10
        elsif (i.tipo == TipoBillete::DE50)
         total+=50
        else
          total+=100
        end
      end
      total      
    end
    
    
#    private
    def nuevo_billete(b)
      @misBilletes<<b
    end
    
    
    def to_s
      aux=""
      aux2=""
      @propiedades.each do |i| 
        aux += i.to_s
      end
      
      @misBilletes.each do |i| 
        aux2 += i.to_s
      end
      "nombre: #{@nombre}, encarcelado #{@encarcelado}, saldo: #{@saldo}, carta_libertad: #{@carta_libertad}, propiedades: #{aux}, titulo propiedad: #{aux2} \n"
    end
    #FIN EXAMEN
    
    
  end
end
