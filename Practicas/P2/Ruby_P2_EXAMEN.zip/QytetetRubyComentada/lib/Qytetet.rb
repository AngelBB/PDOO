#encoding: utf-8
require_relative "dado"
require_relative "metodo_salir_carcel"
require_relative "tablero"
require_relative "jugador"
require "singleton"

module ModeloQytetet
  class Qytetet
    attr_reader :carta_actual, :jugador_actual
    
    include Singleton
    #$
    @@MAX_JUGADORES=4
    @@MAX_CARTAS=10
    @@MAX_CASILLAS=20
    @@PRECIO_LIBERTAD=200
    @@SALDO_SALIDA=1000
    
    def initialize
      @carta_actual=Array.new
      @mazo=Array.new
      #atributos del diagrama de clases
#      @tablero
#      @jugador_actual
      @jugadores =Array.new
      @dado = Dado.instance
      inicializar_cartas_sorpresa
      inicializar_tablero
    end
    
    #metodos del diagrama de clases
    
        
    def aplicar_sorpresa
    end
        
    def cancelar_hipoteca (casilla)
      
    end
    
    def comprar_titulo_propiedad
      
    end
    
    def edificar_casa(casilla)
      
    end
    
    def edificar_hotel(casilla)
      
    end
    
    def get_carta_actual
      
    end
    
    def get_jugador_actual
      
    end
    
    def hipotecar_propiedad(casilla)
      
    end
      
    def inicializar_juego(nombres)
      inicializar_jugadores(nombres)
    end
    
    def intentar_salir_carcel(metodo)
      
    end
    
    def jugar
      
    end
    
    def obtener_ranking
      
    end
    
    def propiedades_hipotecadas_jugador(hipotecadas)
      
    end
    
    def siguiente_jugador
      
    end
    def vender_propiedad(casilla)
      
    end
    
    private
    def encarcelar_jugador
      
    end
      
    def inicializar_cartas_sorpresa
      @mazo=Array.new # Por si acaso ....
      @mazo<< Sorpresa.new("Te ha tocado el bingo ,¡ingresas 2500€!" , 2500,TipoSorpresa::PAGARCOBRAR)
      @mazo<< Sorpresa.new("Se te ha roto el coche ,¡debes pagar 1000€ para arreglarlo!" , 1000,TipoSorpresa::PAGARCOBRAR)
      @mazo<< Sorpresa.new("Te hemos pillado con chanclas y calcetines, lo sentimos, ¡debes ir a la carcel!", 9, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Te echan de menos, ¡debes ir la casilla 13!", 13, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Final de camino, ¡debes ir la casilla 19!", 19, TipoSorpresa::IRACASILLA)
      @mazo<< Sorpresa.new("Vaya te ha llegado la factura del IVA,¡tienes que pagar 500€ por cada cada casa o hotel edificado!", 500, TipoSorpresa::PORCASAHOTEL)
      @mazo<< Sorpresa.new("Han encontrado restos fosiles en tus propiedades,¡recibes 750€ por cada cada casa o hotel edificado!", 750, TipoSorpresa::PORCASAHOTEL)
      @mazo<< Sorpresa.new("Has perdido la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @mazo<< Sorpresa.new("Has ganado la apuesta con tus rivales,¡tienes que pagar a cada jugador 1000€!", 1000,TipoSorpresa::PORJUGADOR)
      @mazo<< Sorpresa.new("Un fan anónimo ha pagado tu fianza. Sales de la cárcel", 0, TipoSorpresa::SALIRCARCEL)
    end
    
    def inicializar_jugadores(nombres)
      nombres.each do |i|
        @jugadores<<i
      end
    end
    
    def inicializar_tablero
      @tablero=Tablero.new
    end
    
    def salida_jugadores
      
    end
    
  #private_class_method :new
  #SOLO PRUEBAS
#    public
#    def mostrar_mazo
#     Mostramos el mazo
#      aux=Array.new
#      @mazo.each do |i|
#       
#          aux<<i
#        
#      end
#      aux
#      
#    end
#    
#     def mostrar_tablero
#      #Mostramos el tablero
#      @tablero.to_s
#     end
#    
#     def mostrar_jugadores
#      #Mostramos los jugadores
#      aux=Array.new
#      @jugadores.each do |i|
#         aux<<i
#      end
#      aux
#      
#    end

    
      
    end
    
  
    
  end
      
