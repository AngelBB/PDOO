#encoding: utf-8

module ModeloQytetet
  class Tablero
    attr_reader :carcel
    
    def initialize
      @casillas=Array.new
      inicializar
   end
    
    def to_s
      cadena=""
      @casillas.each {|v| cadena = cadena + v.to_s}
      cadena
    end
    
    private
    def inicializar
      @carcel=Casilla.casilla_no_calle(10,0,TipoCasilla::CARCEL)
      @casillas<<Casilla.casilla_no_calle(0,0,TipoCasilla::SALIDA)
      @casillas<<Casilla.casilla_si_calle(1,0,TituloPropiedad.new("San Anton",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(2,0,TipoCasilla::SORPRESA)
      @casillas<<Casilla.casilla_si_calle(3,0,TituloPropiedad.new("Recogidas",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_si_calle(4,0,TituloPropiedad.new("Gran Via",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(5,0,TipoCasilla::JUEZ)
      @casillas<<Casilla.casilla_si_calle(6,0,TituloPropiedad.new("Pedro Antonio",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(7,0,TipoCasilla::SORPRESA)
      @casillas<<Casilla.casilla_si_calle(8,0,TituloPropiedad.new("Camino de Ronda",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_si_calle(9,0,TituloPropiedad.new("Reyes Catolicos",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<@carcel
      @casillas<<Casilla.casilla_si_calle(11,0,TituloPropiedad.new("Avd. Constitucion",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_si_calle(12,0,TituloPropiedad.new("Avd. de Andalucia",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(13,0,TipoCasilla::PARKING)
      @casillas<<Casilla.casilla_si_calle(14,0,TituloPropiedad.new("Mesones",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(15,0,TipoCasilla::SORPRESA)
      @casillas<<Casilla.casilla_si_calle(16,0,TituloPropiedad.new("San Juan de Dios",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_si_calle(17,0,TituloPropiedad.new("Arabial",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
      @casillas<<Casilla.casilla_no_calle(18,0,TipoCasilla::IMPUESTO)
      @casillas<<Casilla.casilla_si_calle(19,0,TituloPropiedad.new("Severo Ochoa",false,rand(50..100),rand(10..20),rand(150..1000),rand(250..750)))
    end
  end
end
