#encoding: utf-8

require_relative "tipo_casilla"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Casilla
    attr_reader :numero_casilla, :coste, :tipo 
    attr_accessor :num_hoteles, :num_casas , :titulo
    
    def initialize(nc,c,nh=0,nca=0,tc,t)
      @numero_casilla=nc
      @coste=c
      @num_hoteles=nh
      @num_casas=nca
      @tipo=tc
      @titulo=t
    end
  
    def self.casilla_no_calle(nc,c,tc)
      if(tc != TipoCasilla::CALLE )
        self.new(nc,c,0,0,tc,nil)#CUIDADO CON LOS NULL
      end
    end

    def self.casilla_si_calle(nc,c,tp)
      if( !tp.nil?)
        self.new(nc,c,0,0,tp)
      end
    end
    
   private :titulo
    
   
    public
    def to_s
      if (@titulo.nil?)
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad: - \n"
      else
        "Numero casilla: #{@numero_casilla}, coste: #{@coste}, num_hoteles: #{@num_hoteles}, num_casas: #{@num_casas}, tipo: #{@tipo}, titulo propiedad: #{@titulo.to_s}"
      end
    end
  end
end