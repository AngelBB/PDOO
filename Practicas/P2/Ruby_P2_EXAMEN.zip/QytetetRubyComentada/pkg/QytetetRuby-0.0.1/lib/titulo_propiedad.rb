#encoding: utf-8

module ModeloQytetet
  class TituloPropiedad
    attr_reader :nombre, :alquiler_base, :factor_revalorizacion, :hipoteca_base, :precio_edificar
    attr_accessor :hipotecada
    
    def initialize (n,h=false,ab,fr,hb,pe)
      @nombre=n
      @hipotecada=h  
      @alquiler_base=ab
      @factor_revalorizacion=fr
      @hipoteca_base=hb
      @precio_edificar=pe
    end
    
    def to_s
      "nombre: #{@nombre}, hipotecada: #{@hipotecada}, alquiler base: #{@alquiler_base}, factor revalorizacion: #{@factor_revalorizacion}, hipoteca base: #{@hipoteca_base}, precio edificar: #{@precio_edificar}\n"
    end
  end
end
