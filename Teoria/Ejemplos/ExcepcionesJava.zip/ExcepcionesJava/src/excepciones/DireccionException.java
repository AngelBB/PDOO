
package excepciones;


public class DireccionException extends Exception{
    public DireccionException(String error){
        super(error);
    }    
}
