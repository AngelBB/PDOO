
package X.Y.U; 
import X.Z.V.B;
 

public class A {
    private X.E e;
    private X.Y.C c;
    private X.Z.D d;
    private B b;
    
}
