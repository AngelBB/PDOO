
module X
  module Z
    module V     
      class F  
        
      end
    end
  end
end
