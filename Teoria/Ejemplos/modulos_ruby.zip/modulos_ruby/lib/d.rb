
module X
  module Z
    class D
        
    end
  end
end