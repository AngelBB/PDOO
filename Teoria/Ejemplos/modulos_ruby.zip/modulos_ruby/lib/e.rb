
module X
  class E 
    
  end       
end
