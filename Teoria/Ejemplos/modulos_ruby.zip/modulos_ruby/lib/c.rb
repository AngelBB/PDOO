
 
module X
  module Y
    class C
     
    end
    
  end
end
